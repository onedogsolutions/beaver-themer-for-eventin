<?php
    wp_head();
    
    $ticket_file_name   = sanitize_title_with_dashes( $attendee_name );
    $payment_status     = get_post_meta( $attendee_id, 'etn_status', true );

    $all_payment_status = [
        'success' => esc_html__('Success', 'eventin-pro'),
        'failed'  => esc_html__('Failed', 'eventin-pro')
    ];

    // Load ticket layout style
    wp_enqueue_style('etn-ticket-markup');
    wp_enqueue_script('etn-pdf-gen');
    wp_enqueue_script('etn-html-2-canvas');
    wp_enqueue_script('etn-dom-purify-pdf');
    wp_enqueue_script('html-to-image');
    
    // Include QR Code related scripts when pro plugin is activated
    if(class_exists('Wpeventin_Pro')) {
        wp_enqueue_script('etn-qr-code');
        wp_enqueue_script('etn-qr-code-scanner');
        wp_enqueue_script('etn-qr-code-custom');
    }

?>

<script>
(function() {
    function attachCustomDownloadHandler() {
        const downloadBtn = document.getElementById('etn_ticket_download_btn');
        if (!downloadBtn) return;
        
        // Check if handler already attached to prevent duplicates
        if (downloadBtn.dataset.customHandlerAttached === 'true') return;
        
        // Mark as handled to prevent duplicate attachment
        downloadBtn.dataset.customHandlerAttached = 'true';
        
        // Remove all existing event listeners by cloning and replacing
        const newBtn = downloadBtn.cloneNode(true);
        newBtn.dataset.customHandlerAttached = 'true';
        downloadBtn.parentNode.replaceChild(newBtn, downloadBtn);
        
        // Add custom handler for style-2
        newBtn.addEventListener('click', async function(e) {
            e.preventDefault();
            e.stopImmediatePropagation(); // Prevent other listeners from firing
            
            const jsPDF = window.jspdf.jsPDF;
            newBtn.classList.add('etn-button-loading');
            
            const ticketWrapper = document.querySelector('.etn-ticket-wrapper.ticket-style-2');
            if (!ticketWrapper) {
                console.error('Ticket wrapper not found');
                newBtn.classList.remove('etn-button-loading');
                return;
            }
            
            // Wait for images to load
            await Promise.all(
                Array.from(ticketWrapper.querySelectorAll('img')).map((img) => {
                    if (img.complete) return Promise.resolve();
                    return new Promise((resolve) => {
                        img.onload = resolve;
                        img.onerror = resolve;
                    });
                })
            );
            
            try {
                // Create offscreen clone with proper styling
                const cloneContainer = document.createElement('div');
                cloneContainer.style.cssText = 'position:fixed;left:-100000px;top:0;z-index:-1;';
                
                const clone = ticketWrapper.cloneNode(true);
                
                // Force style-2 layout on clone
                clone.style.cssText = 'width:810px !important;max-width:810px !important;';
                
                const mainWrapper = clone.querySelector('.etn-ticket-main-wrapper');
                if (mainWrapper) {
                    mainWrapper.style.cssText = 'max-width:810px;width:810px;display:flex;flex-wrap:wrap;padding:40px;border:1px solid #d8d9df;border-radius:14px;background:#fff;box-sizing:border-box;';
                }
                
                const leftSide = clone.querySelector('.ticket-left-side');
                if (leftSide) {
                    leftSide.style.cssText = 'flex:0 0 40%;max-width:40%;padding-right:30px;box-sizing:border-box;';
                }
                
                const content = clone.querySelector('.etn-ticket-content');
                if (content) {
                    content.style.cssText = 'flex:0 0 60%;max-width:60%;padding-left:30px;border-left:1px solid #eaeaea;box-sizing:border-box;';
                }
                
                cloneContainer.appendChild(clone);
                document.body.appendChild(cloneContainer);
                
                // Render to canvas with appropriate settings
                const canvas = await window.html2canvas(clone, {
                    useCORS: true,
                    allowTaint: true,
                    scrollX: 0,
                    scrollY: 0,
                    scale: 2, // Reduced from 7 to 2 for better compatibility
                    logging: false,
                    width: 810,
                    backgroundColor: '#ffffff'
                });
                
                const dataUrl = canvas.toDataURL('image/png');
                const img = new Image();
                
                img.onload = () => {
                    const doc = new jsPDF({
                        orientation: 'landscape',
                        unit: 'px',
                        format: 'a4'
                    });
                    
                    const pageWidth = doc.internal.pageSize.getWidth();
                    const pageHeight = doc.internal.pageSize.getHeight();
                    
                    // Calculate scaling to fit with margins
                    const margin = 20;
                    const scale = Math.min(
                        (pageWidth - margin * 2) / canvas.width,
                        (pageHeight - margin * 2) / canvas.height
                    );
                    
                    const width = canvas.width * scale;
                    const height = canvas.height * scale;
                    const x = (pageWidth - width) / 2;
                    const y = (pageHeight - height) / 2;
                    
                    doc.addImage(img, 'PNG', x, y, width, height, undefined, 'FAST');
                    
                    const filename = newBtn.getAttribute('data-ticketname') || 'ticket';
                    doc.save(filename + '.pdf');
                    
                    // Cleanup
                    newBtn.classList.remove('etn-button-loading');
                    if (cloneContainer.parentNode) {
                        cloneContainer.parentNode.removeChild(cloneContainer);
                    }
                };
                
                img.onerror = (error) => {
                    console.error('Image loading failed:', error);
                    newBtn.classList.remove('etn-button-loading');
                    if (cloneContainer.parentNode) {
                        cloneContainer.parentNode.removeChild(cloneContainer);
                    }
                };
                
                img.src = dataUrl;
                
            } catch (error) {
                console.error('PDF generation failed:', error);
                newBtn.classList.remove('etn-button-loading');
            }
        });
    }
    
    // Try immediately, then on DOMContentLoaded as fallback
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', attachCustomDownloadHandler);
    } else {
        attachCustomDownloadHandler();
    }
})();
</script>


<meta name="viewport" content="width=device-width, initial-scale=1">
<div class="etn-ticket-download-wrapper">
    <div class="etn-ticket-wrap" id="etn_attendee_details_to_print" >
      <div class="etn-ticket-wrapper ticket-style-2">
            <div class="etn-ticket-main-wrapper">
                <div class="ticket-left-side">
                <?php  if(has_custom_logo()){ ?>
                          <div class="etn-ticket-logo-wrapper">
                             <?php 
                                $custom_logo_id = get_theme_mod( 'custom_logo' );
                                $image = wp_get_attachment_image_src( $custom_logo_id, 'Full' );
                            ?>
                             <img style="max-width: 150px; max-height: 70px; object-fit: cover"  src="<?php echo esc_url($image[0]); ?>" />

                            <div class="logo-shape">
                                <span class="logo-bar bar-one" ></span>
                                <span class="logo-bar bar-two" ></span>
                                <span class="logo-bar bar-three" ></span>
                            </div>
                        </div>
                    <?php    
                        }elseif( class_exists( 'ET_Builder_Element' ) ){ 
                    ?>
                        <div class="etn-ticket-logo-wrapper">
                             <?php 
                                $image = et_get_option( 'divi_logo');
                            ?>
                             <img style="max-height: 70px; object-fit: cover"  src="<?php echo esc_url($image); ?>" />

                            <div class="logo-shape">
                                <span class="logo-bar bar-one" ></span>
                                <span class="logo-bar bar-two" ></span>
                                <span class="logo-bar bar-three" ></span>
                            </div>
                        </div>
                    <?php             
                        } 
                    ?>

                    <div class="etn-ticket-qr-code">
                        <?php
                            if( $payment_status ==='success'){
                                do_action('etn_pro_ticket_qr', $attendee_id, $event_id);
                            }
                        ?>
                    </div>
                </div>
                <div class="etn-ticket-content"> 
                    <div class="etn-ticket-head">
                        <h3 class="etn-ticket-head-title"><?php echo esc_html( $event_name ) ?></h3>
                        <ul class="etn-ticket-body-top-ul">
                            <?php if ( $date !== "") : ?>
                                <li class="etn-ticket-body-top-li">
                                    <p><?php echo esc_html__( "Date :", "eventin-pro" ); ?> </p>
                                    <?php echo esc_html( $date ) ?>  
                                </li>
                            <?php endif; ?>

                            <?php if ( $time !== "") : ?>
                                <li class="etn-ticket-body-top-li">
                                    <p><?php echo esc_html__( "Time :", "eventin-pro" ); ?> </p>
                                    <?php echo esc_html( $time ) ?>  
                                </li>
                            <?php endif; ?>
                            <?php $location = \Etn\Core\Event\Helper::instance()->display_event_location($event_id); ?>
                            <?php if ( !empty($location)) { ?>
                                <li class="etn-ticket-body-top-li">
                                    <p><?php echo esc_html__( "VENUE :", "eventin-pro" ); ?></p> 
                                    <p><?php echo esc_html( $location ) ?></p>
                                </li>
                            <?php }?>
                           
                        </ul>
                    </div>
                    <div class="etn-ticket-body">
                        <div class="etn-ticket-body-top">
                            <div class="etn-ticket-body-top-ul-wrapper">
                                <ul class="etn-ticket-body-top-ul">
                                    <?php do_action('etn_pro_ticket_id', $attendee_id, $event_id); ?>
                                    <?php if ( $ticket_price !== "") { ?>
                                        <li class="etn-ticket-body-top-li">
                                        <p><?php echo esc_html__( "PRICE :", "eventin-pro" ); ?> </p>
                                            
                                                <?php 
                                                    if ( class_exists('WooCommerce') ) {
                                                        $ticket_price = is_float( $ticket_price ) ? wc_format_decimal( $ticket_price, wc_get_price_decimals() ) : $ticket_price;

                                                        $currency_symbol = get_woocommerce_currency_symbol();
                                                        $currency_pos 	 = get_option( 'woocommerce_currency_pos' );
                                                        if ( $currency_pos == 'left_space' ) {
                                                            $currency_symbol = $currency_symbol . ' ';
                                                        } elseif ( $currency_pos == 'right_space' ) {
                                                            $currency_symbol = ' ' . $currency_symbol;
                                                        }

                                                        $print_left = ( strpos( $currency_pos, 'left' ) !== false ) ? true : false;
                                                        echo ( $print_left ) ? $currency_symbol . esc_html( $ticket_price ):  esc_html( $ticket_price ) . $currency_symbol;
                                                    } else {
                                                        $ticket_price = is_float( $ticket_price ) ? number_format( $ticket_price, 2 ) : $ticket_price;
                                                    }
                                                ?>
                                            
                                        </li>
                                    <?php }?>
                                    <?php if ( $ticket_name !== "") { ?>
                                        <li class="etn-ticket-body-top-li flex-100">
                                            <p><?php echo esc_html__( "TYPE :", "eventin-pro" ); ?> </p>
                                            <?php echo esc_html( $ticket_name ) ?>
                                        </li>
                                    <?php }?>
                                    <?php if ( $attendee_seat !== "") { ?>
                                        <li class="etn-ticket-body-top-li flex-100">
											<?php echo esc_html__( "Seat :", "eventin-pro" ); ?> 
                                            <p><?php echo esc_html( $attendee_seat ) ?></p>
                                        </li>
                                    <?php }?>

                                 
                                    <?php if ( $attendee_name !== "") { ?>
                                        <li class="etn-ticket-body-top-li">
                                            <p><?php echo esc_html__( "ATTENDEE :", "eventin-pro" ); ?> </p>
                                            <?php echo esc_html( $attendee_name ) ?>
                                        </li>
                                    <?php }?>
                                    
                                    <?php if ( $include_phone  && $attendee_phone !== "") { ?>
                                        <li class="etn-ticket-body-top-li">
                                            <p><?php echo esc_html__( "PHONE :", "eventin-pro" ); ?> </p>
                                            <?php echo esc_html( $attendee_phone ) ?>
                                        </li>
                                    <?php }?>
                                    <?php if ( $include_email && $attendee_email !== "" ) { ?>
                                        <li class="etn-ticket-body-top-li">
                                            <p><?php echo esc_html__( "EMAIL :", "eventin-pro" ); ?> </p>
                                            <?php echo esc_html( $attendee_email ) ?>
                                        </li>
                                    <?php }?>

                                    <?php if($payment_status){ ?>
                                        <li class="etn-ticket-body-top-li">
                                            <p><?php echo esc_html__( "Payment Status :", "eventin-pro" ); ?> </p>
                                            <?php echo esc_html( $all_payment_status[$payment_status] ); ?>
                                        </li>
                                    <?php } ?>
                                </ul>
                        </div>
                    </div>
                </div>
            </div>
      </div>
    </div>
</div>
<div class="etn-download-ticket">
    <button class="etn-btn button etn-print-ticket-btn" id="etn_ticket_print_btn" data-ticketname="<?php echo esc_html( $ticket_file_name )?>" ><?php echo esc_html__( "Print", "eventin-pro" ); ?></button>
    <button class="etn-btn button etn-download-ticket-btn" id="etn_ticket_download_btn" data-ticketname="<?php echo esc_html( $ticket_file_name )?>" ><?php echo esc_html__( "Download", "eventin-pro" ); ?></button>
</div>

<?php wp_footer(); ?>

