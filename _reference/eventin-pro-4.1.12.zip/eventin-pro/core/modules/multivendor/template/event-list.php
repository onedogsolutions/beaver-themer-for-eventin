<?php
    global $post;
?>

<?php do_action( 'dokan_dashboard_wrap_start' ); ?>

<div class="dokan-dashboard-wrap">
    <?php
        /**
         *  dokan_dashboard_content_before hook
         *
         *  @hooked get_dashboard_side_navigation
         *
         *  @since 2.4
         */
        do_action( 'dokan_dashboard_content_before' );
    ?>

    <div class="dokan-dashboard-content">
        
        <?php
            /**
             *  dokan_dashboard_content_before hook
             *
             *  @hooked show_seller_dashboard_notice
             *
             *  @since 2.4
             */

            do_action( 'dokan_eventin_content_inside_before' );

        ?>

        <article class="wpc-content-area">

            <!-- Show response message -->
            <div class="dokan-ajax-response">
                <?php do_action( 'dokan_settings_load_ajax_response' ); ?>
            </div>
            
        </article>

        <!-- .dashboard-content-area -->

        <!-- Start Markup -->
        <div id="etn_multivendor_form" class="etn-multivendor-form"></div>
        <!-- End Markup -->


        <?php
            /**
             *  dokan_dashboard_content_inside_after hook
             *
             *  @since 2.4
             */
            do_action( 'dokan_dashboard_content_inside_after' );
        ?>


    </div><!-- .dokan-dashboard-content -->

    <?php
        /**
         *  dokan_dashboard_content_after hook
         *
         *  @since 2.4
         */
        do_action( 'dokan_dashboard_content_after' );
    ?>

    </div><!-- .dokan-dashboard-wrap -->
    
<?php 
// Include Eventin AI modal for Dokan vendor dashboard
if ( class_exists( '\Etn\Core\Modules\Eventin_Ai\Eventin_AI' ) && file_exists( \Wpeventin::core_dir() . 'modules/eventin-ai/admin/view/modal.php' ) ) {
    include_once \Wpeventin::core_dir() . 'modules/eventin-ai/admin/view/modal.php';
}

do_action( 'dokan_dashboard_wrap_end' ); ?>