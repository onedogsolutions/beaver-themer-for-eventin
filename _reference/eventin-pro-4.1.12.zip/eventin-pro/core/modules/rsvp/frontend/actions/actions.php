<?php

namespace Etn_Pro\Core\Modules\Rsvp\Frontend\Actions;

defined( 'ABSPATH' ) || die();

class Actions {

	use \Etn_Pro\Traits\Singleton;

	public function init() {
		// Live RSVP submissions go through the REST endpoint
		// EventinPro\Core\Modules\Rsvp\Api\RsvpController::create_item.
		// The legacy wp_ajax_(nopriv_)etn_rsvp_insert handler used to live here
		// but the form HTML it served is no longer rendered (replaced by the
		// React mount in rsvp-form.php), and the unauthenticated handler had
		// known abuse paths (mass insert / email bomb / attendee tampering).
	}
}
