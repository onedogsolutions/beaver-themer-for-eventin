<?php
/**
 * RSVP Api Class
 *
 * @package Eventin\Event
 */
namespace Etn_Pro\Core\Modules\Rsvp\Api;

use Eventin\Attendee\RsvpExporter;
use Eventin\Attendee\RsvpImporter;
use EventinPro\modules\rsvp\RsvpService;
use WP_Error;
use WP_Query;
use WP_REST_Controller;
use WP_REST_Server;
use DateTime;
use DateInterval;
use Etn\Core\Event\Event_Model;
use Etn\Utils\Helper;
/**
 * RSVP Controller Class
 */
class RsvpController extends WP_REST_Controller {

    /**
     * Constructor for EventController
     *
     * @return void
     */
    public function __construct() {
        $this->namespace = 'eventin/v2';
        $this->rest_base = 'rsvp-report';
    }

    /**
     * Check if a given request has access to get items.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|boolean
     */
    public function register_routes() {
        register_rest_route( $this->namespace, $this->rest_base, [
            [
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => [$this, 'delete_items'],
                'permission_callback' => [$this, 'delete_item_permissions_check'],
            ],
        ] );

        register_rest_route( $this->namespace, 'rsvp-registration', [
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'create_item'],
                'permission_callback' => [$this, 'create_item_permissions_check'],
            ]
        ] );

        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)',
            array(
                'args'   => array(
                    'id' => array(
                        'description' => __( 'Unique identifier for the post.', 'eventin-pro' ),
                        'type'        => 'integer',
                    ),
                ),
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_item' ),
                    'permission_callback' => array( $this, 'get_item_permissions_check' ),
                    'args'                => $this->get_collection_params(),
                ),
                array(
                    'methods'             => WP_REST_Server::DELETABLE,
                    'callback'            => array( $this, 'delete_item' ),
                    'permission_callback' => array( $this, 'delete_item_permissions_check' ),
                    'args'                => array(
                        'force' => array(
                            'type'        => 'boolean',
                            'default'     => false,
                            'description' => __( 'Whether to bypass Trash and force deletion.', 'eventin-pro' ),
                        ),
                    ),
                ),
                // 'allow_batch' => $this->allow_batch,
                'schema' => array( $this, 'get_item_schema' ),
            ),
        );
        
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)'. '/invitations',
            array(
                array(
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => array( $this, 'invite_item' ),
                    'permission_callback' => array( $this, 'edit_item_permissions_check' ),
                    'args'                => $this->get_collection_params(),
                ),
                // 'allow_batch' => $this->allow_batch,
                'schema' => array( $this, 'get_item_schema' ),
            ),
        );
	    
	    
	    register_rest_route( $this->namespace, $this->rest_base . '/export', [
		    [
			    'methods'             => WP_REST_Server::CREATABLE,
			    'callback'            => [$this, 'export_items'],
			    'permission_callback' => [$this, 'export_item_permissions_check'],
		    ],
	    ] );
	    
	    register_rest_route( $this->namespace, $this->rest_base . '/import', [
		    [
			    'methods'             => WP_REST_Server::CREATABLE,
			    'callback'            => [$this, 'import_items'],
			    'permission_callback' => [$this, 'import_item_permissions_check'],
		    ],
	    ] );
    }

    /**
     * Check if a given request has access to get items.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|boolean
     */
    public function get_item_permissions_check( $request ) {
        if ( current_user_can( 'etn_manage_event' ) ) {
            return true;
        }

        // Allow the public RSVP form's "going attendees" list when the event
        // owner has explicitly opted in via rsvp_settings.show_rsvp_attendee.
        $event_id     = isset( $request['id'] ) ? absint( $request['id'] ) : 0;
        $status       = isset( $request['status'] ) ? sanitize_text_field( $request['status'] ) : '';
        $rsv_settings = $event_id ? get_post_meta( $event_id, 'rsvp_settings', true ) : [];
        $public       = ! empty( $rsv_settings['show_rsvp_attendee'] ) && $rsv_settings['show_rsvp_attendee'];

        return $public && 'going' === $status;
    }
    
    /**
     * Check if a given request has access to edit items.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|boolean
     */
    public function edit_item_permissions_check( $request ) {
        return current_user_can( 'etn_manage_event' );
    }

    /**
     * Checks if a given request has access to register rsvp attendees.
     *
     *
     * @param WP_REST_Request $request Full details about the request.
     * @return true|WP_Error True if the request has access to register rsvp attendees, WP_Error object otherwise.
     */
    public function create_item_permissions_check( $request ) {
        $nonce = $request->get_header( 'x-wp-nonce' );
        if ( wp_verify_nonce( $nonce, 'wp_rest' ) ) {
            return true;
        }
        return false;
    }

    /**
     * Check if a given request has access to export items.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|boolean
     */
    public function create_item( $request ) {
        $data = $request->get_params();

        $event_id = isset( $data['event_id'] ) ? intval( $data['event_id'] ) : 0;
        $number_of_attendee = isset( $data['number_of_attendee'] ) ? intval( $data['number_of_attendee'] ) : 0;
        $etn_rsvp_value = isset( $data['etn_rsvp_value'] ) ? sanitize_text_field( $data['etn_rsvp_value'] ) : '';
        $rsvp_not_going_reason = isset( $data['rsvp_not_going_reason'] ) ? sanitize_text_field( $data['rsvp_not_going_reason'] ) : '';
        $parent_attendee = isset( $data['parent_attendee'] ) && is_array( $data['parent_attendee'] ) ? $data['parent_attendee'] : [];
        $child_attendees = isset( $data['child_attendees'] ) && is_array( $data['child_attendees'] ) ? $data['child_attendees'] : [];

        if ( empty( $event_id ) || empty( $parent_attendee ) ) {
            return rest_ensure_response( [
                'success' => false,
                'message' => __( 'Event ID, parent attendee details, and child attendees are required.', 'eventin-pro' ),
            ] );
        }

        $all_attendee_emails = [];

        $email = isset( $parent_attendee['attendee_email'] ) ? sanitize_text_field( $parent_attendee['attendee_email'] ) : '';
        $all_attendee_emails[] = $email;

        foreach ( $child_attendees as $child ) {
            if ( isset( $child['attendee_email'] ) && !empty( $child['attendee_email'] ) ) {
                $all_attendee_emails[] = sanitize_text_field( $child['attendee_email'] );
            }
        }

        $meta_value = get_post_meta( $event_id, 'rsvp_settings', true );
        $enable_rsvp_form = isset( $meta_value['verify_rsvp_submission'] ) ? $meta_value['verify_rsvp_submission'] : false;

        $check_if_attendee_exists = $this->check_if_attendee_exists( $all_attendee_emails, $event_id );

        if ( $enable_rsvp_form == 'on' && $check_if_attendee_exists ) {
            return new WP_Error(
                'rest_invalid_post_type',
                __( 'RSVP already exists for this attendee.', 'eventin-pro' ),
                array( 'status' => 403 )
            );
        }

        $parent_id = $this->add_rsvp_attendee(
            $event_id,
            $number_of_attendee,
            $etn_rsvp_value,
            $rsvp_not_going_reason,
            $parent_attendee
        );

        foreach ( $child_attendees as $child ) {
            if ( isset( $child['attendee_email'] ) && !empty( $child['attendee_email'] ) ) {
                $this->add_rsvp_attendee(
                    $event_id,
                    0,
                    '',
                    '',
                    $child, $parent_id
                );
            }
        }

        $email_data = [
            'event_id' => $event_id,
            'attendee_email' => $all_attendee_emails,
        ];

        $this->etn_rsvp_email_data($email_data);

        do_action( 'eventin_rsvp_created', get_post( $parent_id ), $data );

        return rest_ensure_response( [
            'success' => true,
            'message' => __( 'RSVP created successfully.', 'eventin-pro' ),
        ] );
    }

    /**
     * Export RSVP items.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function add_rsvp_attendee( $event_id, $number_of_attendee, $etn_rsvp_value, $rsvp_not_going_reason, $attendee, $parent_id = null ) {
        $attendee_name = isset( $attendee['attendee_name'] ) ? sanitize_text_field( $attendee['attendee_name'] ) : '';

        $args = [
            'post_title'   => $attendee_name,
            'post_content' => '',
            'post_status'  => 'publish',
            'post_author'  => '1',
            'post_parent'  => !empty( $parent_id ) ? $parent_id : 0,
            'post_type'    => 'etn_rsvp',
        ];

        $rsvp_id = wp_insert_post( $args );

        foreach ( $attendee as $meta_key => $meta_value ) {

            if ( !empty( $meta_value ) ) {
                add_post_meta( $rsvp_id, $meta_key, $meta_value );
            }

        }

        add_post_meta( $rsvp_id, 'event_id', $event_id );

        if ( empty( $parent_id ) ) {
            add_post_meta( $rsvp_id, 'number_of_attendee', $number_of_attendee );
            add_post_meta( $rsvp_id, 'etn_rsvp_value', $etn_rsvp_value );
            add_post_meta( $rsvp_id, 'rsvp_not_going_reason', $rsvp_not_going_reason );
        }

        return $rsvp_id;
    }

    /**
     * Check if a given request has access to export items.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|boolean
     */
    public function check_if_attendee_exists( $attendee_emails, $event_id ) {
        $args = [
            'post_status'    => 'publish',
            'post_type'      => 'etn_rsvp',
            'posts_per_page' => -1,
            'meta_query'     => [
                'relation' => 'AND',
                [
                    'key'     => 'attendee_email',
                    'value'   => $attendee_emails,
                    'compare' => 'IN',
                ],
                [
                    'key'   => 'event_id',
                    'value' => $event_id,
                ],
            ],
        ];
        $query = new WP_Query( $args );

        if ( $query->have_posts() ) {
            return true;
        }

        return false;
    }


    /**
     * Get one item from the collection.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function get_item( $request ) {
        $id                 = intval( $request['id'] );
        $rsvp_start_date    = $request['rsvp_start_date'];
        $rsvp_end_date      = $request['rsvp_end_date'];
        $status             = sanitize_text_field( $request['status'] );
        $rsvp_limit_amount  = '';
        $rsvp_title         = sanitize_text_field( $request['attendee_name'] );
        $rsvp               = [];
        $event_data         = get_post_meta( $id, 'rsvp_settings', true );
        $rsvp_date_range    = !empty($request['rsvp_date_range']) ? $request['rsvp_date_range'] : '';
        $posts_per_page     = isset($request['posts_per_page']) ? intval($request['posts_per_page']) : -1;
        $paged              = isset($request['paged']) ? intval($request['paged']) : 1;

        $attendee_avatar    = apply_filters("etn/speakers/avatar", \Wpeventin::assets_url() . "images/avatar.jpg");


        if( $event_data ) {
            $rsvp_limit_amount = isset( $event_data['etn_rsvp_limit_amount'] ) ? $event_data['etn_rsvp_limit_amount'] : '';
        }
        // Define query arguments to match the CPT and meta key
        $args = array(
            'post_type'  => 'etn_rsvp',
            'post_parent' => 0,
            'meta_query' => array(
                array(
                    'key'     => 'event_id',
                    'value'   => $id,
                    'compare' => '=',
                )
            ),
            'posts_per_page' => $posts_per_page,
            'paged'          => $paged
        );

        // Add additional meta_query if status is not empty
        if ( !empty( $status ) ) {
            $args['meta_query'][] = array(
                'key'     => 'etn_rsvp_value',
                'value'   => [str_replace( ['_', '-'], ' ', $status ),str_replace( ['_', '-'], '_', $status )],
                'compare' => 'IN',
            );
        }

        // Add search query if name is not empty
        if ( !empty( $rsvp_title ) ) {
            $args['s'] = $rsvp_title;
        }
        

        if ( !empty( $rsvp_start_date ) && !empty( $rsvp_end_date ) ) {
            $args['date_query'] = array(
                array(
                    'after'     => $rsvp_start_date,
                    'before'    => $rsvp_end_date,
                    'inclusive' => true,
                ),
            );
        }

        // Calculate the date range based on rsvp_date_range
        if ( !empty( $rsvp_date_range ) ) {
            $current_date = new DateTime();
            if ($rsvp_date_range === 'today') {
                $start_date = $current_date->format( 'Y-m-d' );
                $end_date = $current_date->format( 'Y-m-d' );
            } else {
                $start_date = $current_date->sub( new DateInterval( 'P' . intval($rsvp_date_range) . 'D' ) )->format( 'Y-m-d' );
                $end_date = (new DateTime())->format( 'Y-m-d' );
            }

            $args['date_query'] = array(
                array(
                    'after'     => $start_date,
                    'before'    => $end_date,
                    'inclusive' => true,
                ),
            );
        }

        // Perform the query
        $query          = new WP_Query( $args );
        $total_count    = $query->found_posts;

        $query_result           = $query->posts;
        $rsvp['event_title']    = get_the_title( $id );
        $rsvp['rsvp_limit']     = $rsvp_limit_amount ? $rsvp_limit_amount : 0;

        $rsvp_count             = $this->get_etn_rsvp_counts( $query_result );
        $rsvp['going']          = isset( $rsvp_count['going'] ) ? $rsvp_count['going'] : 0;
        $rsvp['not_going']      = isset( $rsvp_count['not going'] ) ? $rsvp_count['not going'] : 0;
        $rsvp['maybe']          = isset( $rsvp_count['maybe'] ) ? $rsvp_count['maybe'] : 0;

        $rsvp['items']          = [];
        foreach ( $query_result as $post ) {
            $post_data              = $this->prepare_item_for_response( $post, $request );
            $post_data['avatar']    = esc_url( $attendee_avatar );
            $rsvp['items'][]        = $post_data;
        }

        $rsvp['total_items']        = $total_count;

        $response = rest_ensure_response( $rsvp );
        // $response->header( 'X-WP-Total', $total_posts );

        return $response;
    }

    /**
     * Invite RSVP item from the collection.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function invite_item( $request ) {
        $params  = $request->get_params();
        $id      = isset($params['id']) ? intval( $params['id'] ) : 0;
        $from    = ( isset( $params['from'] ) && ! empty( $params['from'] ) ) ? sanitize_email( $params['from'] ) : get_option( 'admin_email' );
        $subject = ( isset( $params['subject'] ) && ! empty( $params['subject'] ) ) ? sanitize_text_field( $params['subject'] ) : get_the_title( $id );
        $body    = ( isset( $params['body'] ) && ! empty( $params['body'] ) ) ? Helper::kses( $params['body'] ) : '';
        $status  = ( isset( $params['status'] ) && ! empty( $params['status'] ) ) ? sanitize_text_field( $params['status'] ) : 'going';

        // Define query arguments to match the CPT and meta key
        $args = array(
            'posts_per_page' => -1,
            'post_type'  => 'etn_rsvp',
            'post_parent' => 0,
            'meta_query' => array(
                array(
                    'key'     => 'event_id',
                    'value'   => $id,
                    'compare' => '=',
                )
            ),
        );

        // Add additional meta_query if status is not empty
        if ( !empty( $status ) ) {
            $args['meta_query'][] = array(
                'key'     => 'etn_rsvp_value',
                'value'   => str_replace( ['_', '-'], ' ', $status ),
                'compare' => '=',
            );
        }

        $shortcodes = $this->get_shortcode_values( $id );
        // Replace shortcodes in the body
        $body = str_replace( array_keys( $shortcodes ), array_values( $shortcodes ), $body );

        // Perform the query
        $query = new WP_Query( $args );

        $query_result           = $query->posts;
        $rsvp                   = [];
        foreach ( $query_result as $post ) {
            $emails = $this->get_speaker_email( $post->ID );
            if (is_array( $emails ) ) {
                foreach ( $emails as $email ) {
                    if ( filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
                        $rsvp[] = $email;
                    }
                }
            }else{
                if ( filter_var( $emails, FILTER_VALIDATE_EMAIL ) ) {
                    $rsvp[] = $emails;
                }
            }
        }
        $rsvp = array_unique( $rsvp );
        $args = array(
            'mail_from'  => $from,
            'mail_to'    => $rsvp,
            'subject'    => $subject,
            'email_body' => $body,
            'type'       => '',
            'from_name'  => get_the_title( $id )
        );

        try {
            $etn_addons_options = get_option( 'etn_addons_options' ) ?? [];
            $is_automation_module_on = 'off';
			if ( is_array( $etn_addons_options ) ) {
				$is_automation_module_on = $etn_addons_options["automation"] ?? "off";
			}

			// check if automation module is on
			if ( 'on' === $is_automation_module_on ) {
                $registration_time = current_time('timestamp');
                foreach ( $rsvp as $attendee_email ) {
                    $placeholder_values = $this->get_placeholder_values( $id, $attendee_email );
                    $placeholder_values['registration_time_timestamp'] = $registration_time;
                    $placeholder_values['session_id'] = uniqid();
                    do_action('global_notification_hook','event_rsvp_email',$placeholder_values);
                }
			}
            else{
                // Create an instance of the Invitations
                $invitation = new \Etn_Pro\Core\Modules\Rsvp\Notifications\Invitations( $args );
            }

            // Return success response
            $response = array(
                'success' => true,
                'message' => 'Emails sent successfully',
                'data'    => $rsvp,
            );
        } catch ( Exception $e ) {
            // Return error response
            $response = array(
                'success' => false,
                'message' => $e->getMessage(),
            );
        }
        // $response->header( 'X-WP-Total', $total_posts );

        return rest_ensure_response( $response );
    }

    /**
     * Delete one item from the collection.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function delete_item( $request ) {
        $id = intval( $request['id'] );
        $post = get_post( $id );
    
        if ( is_wp_error( $post ) ) {
            return $post;
        }
    
        // Check if the post type is 'etn_rsvp'
        if ( $post->post_type !== 'etn_rsvp' ) {
            return new WP_Error(
                'rest_invalid_post_type',
                __( 'This RSVP attende type cannot be deleted.', 'eventin-pro' ),
                array( 'status' => 403 )
            );
        }
    
        $previous = $this->prepare_item_for_response( $post, $request );
        $snapshot = (object) $previous;
        $snapshot->_eventin_rsvp_event = true;
        do_action( 'eventin_rsvp_before_delete', $snapshot );
        $result = wp_delete_post( $id, true );
        $response = new \WP_REST_Response();
        $response->set_data(
            array(
                'deleted'  => true,
                'previous' => $previous,
            )
        );
    
        if ( ! $result ) {
            return new WP_Error(
                'rest_cannot_delete',
                __( 'The RSVP attendee cannot be deleted.', 'eventin-pro' ),
                array( 'status' => 500 )
            );
        }
    
        return $response;
    }

    /**
     * Delete multiple items from the collection.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function delete_items( $request ) {
        $ids = ! empty( $request['ids'] ) ? $request['ids'] : [];

        if ( ! $ids ) {
            return new WP_Error(
                'rest_cannot_delete',
                __( 'RSVP attendee ids can not be empty.', 'eventin-pro' ),
                array( 'status' => 400 )
            );
        }
        $count = 0;

        foreach ( $ids as $id ) {
            $post = get_post( $id );
    
            if ( is_wp_error( $post ) ) {
                return $post;
            }
        
            // Check if the post type is 'etn_rsvp'
            if ( $post->post_type !== 'etn_rsvp' ) {
                return new WP_Error(
                    'rest_invalid_post_type',
                    __( 'RSVP attendee ids can not be empty.', 'eventin-pro' ),
                    array( 'status' => 403 )
                );
            }

            $snapshot = (object) $this->prepare_item_for_response( $post, $request );
            $snapshot->_eventin_rsvp_event = true;
            do_action( 'eventin_rsvp_before_delete', $snapshot );
            $result = wp_delete_post( $id, true );

            if ( $result ) {
                $count++;
            }
        }

        if ( $count == 0 ) {
            return new WP_Error(
                'rest_cannot_delete',
                __( 'RSVP Attendee cannot be deleted.', 'eventin-pro' ),
                array( 'status' => 500 )
            );
        }

        $message = sprintf( __( '%d events are deleted of %d', 'eventin-pro' ), $count, count( $ids ) );
        return rest_ensure_response( $message );
    }


    /**
     * Delete one item from the collection.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function delete_item_permissions_check( $request ) {
        return current_user_can( 'manage_options' ) || current_user_can( 'etn_manage_event' );
    }

    /**
     * Prepare the item for the REST response.
     *
     * @param mixed           $item WordPress representation of the item.
     * @return WP_REST_Response $response
     */
    public function prepare_item_for_response( $item, $request ) {
        $id                 = $item->ID;
        $event_id           = intval( get_post_meta( $id, 'event_id', true ) );
        $attendee_name      = get_the_title( $id );

        $is_admin_view = current_user_can( 'etn_manage_event' );

        // Public list view (gated by rsvp_settings.show_rsvp_attendee in the
        // permission callback) returns only the minimum needed to render the
        // "Who's coming" card grid. Email is included only when the event
        // owner has opted in via rsvp_settings.show_attendee_email.
        if ( ! $is_admin_view ) {
            $rsv_settings = get_post_meta( $event_id, 'rsvp_settings', true );
            $rsvp_data    = [
                'id'            => $id,
                'event_id'      => $event_id,
                'attendee_name' => $attendee_name,
            ];

            if ( ! empty( $rsv_settings['show_attendee_email'] ) ) {
                $rsvp_data['attendee_email'] = get_post_meta( $id, 'attendee_email', true );
            }

            return $rsvp_data;
        }

        $post                  = get_post( $id );
        $number_of_attendee    = intval( get_post_meta( $id, 'number_of_attendee', true ) );
        $etn_rsvp_status       = get_post_meta( $id, 'etn_rsvp_value', true );
        $attendee_email        = get_post_meta( $id, 'attendee_email', true );
        $attendee_phone        = get_post_meta( $id, 'phone', true );
        $attendee_extra_fields = get_post_meta( $id, 'extra_fields', true );
        $rsvp_date             = $post->post_modified;
        $guest                 = $this->get_guest_details( $id );
        $rsvp_not_going_reason = get_post_meta( $id, 'rsvp_not_going_reason', true );

        $total_guest = count( (array) $guest );

        $rsvp_data = [
            'id'                      => $id,
            'number_of_attendee'      => ( $total_guest >= 1 ) ? $total_guest : 0,
            'status'                  => $etn_rsvp_status,
            'event_id'                => $event_id,
            'attendee_name'           => $attendee_name,
            'attendee_email'          => $attendee_email,
            'attendee_phone'          => $attendee_phone,
            'attendee_extra_fields'   => $attendee_extra_fields,
            'received_on'             => $rsvp_date,
            'guest'                   => $guest,
            'rsvp_not_going_reason'   => $rsvp_not_going_reason
        ];

        return $rsvp_data;
    }


    /**
     * Prepare the item for guest details.
     *
     * @param mixed  $post_parent_id WordPress .
     * @return WP_REST_Response $response
     */
    public function get_guest_details( $post_parent_id ) {
        $guests = array();

        $parent_email   = get_post_meta( $post_parent_id, 'attendee_email', true );
        $attendee_count = get_post_meta( $post_parent_id, 'number_of_attendee', true );
        // Set up the query arguments
        $args = array(
            'post_type'   => 'etn_rsvp',
            'post_parent' => $post_parent_id,
            'posts_per_page' => -1
        );
    
        $query = new WP_Query( $args );
    
        // Check if there are posts
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $post_id = get_the_ID();
                
                // Retrieve post meta
                $name = get_the_title( $post_id );
                $email = get_post_meta($post_id, 'attendee_email', true);
                $phone = get_post_meta($post_id, 'phone', true);
                $extra_fields = get_post_meta($post_id, 'extra_fields', true);

                // If parent and child post have the same email, and the attendee is equal to 1, return an empty array
                if ( $email == $parent_email && $attendee_count == 1 ) {
                    wp_reset_postdata();
                    return $guests;
                }

                if ( $name && $email ) {
                    $guests[] = array(
                        'name'  => $name,
                        'email' => $email,
                        'phone' => $phone,
                        'extra_fields' => $extra_fields
                    );
                }
            }
            wp_reset_postdata();
        }
    
        // Return the array of guest objects
        return $guests;
    }
    
    
    /**
     * Prepare the item for guest details.
     *
     * @param mixed  $post_parent_id WordPress .
     * @return WP_REST_Response $response
     */
    public function get_speaker_email( $post_parent_id ) {
        $emails = array();
        $parent_email = get_post_meta( $post_parent_id, 'attendee_email', true );
    
        // Set up the query arguments
        $args = array(
            'post_type'   => 'etn_rsvp',
            'post_parent' => $post_parent_id,
            'posts_per_page' => -1,
            'post_status' => 'publish',
        );
    
        // Create a new WP_Query instance
        $query    = new WP_Query( $args );
        //add post parent id
        $emails[] = $parent_email;
        // Check if there are posts
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $post_id = get_the_ID();
    
                // Retrieve email from child post
                $post_email = get_post_meta( $post_id, 'attendee_email', true );
    
                // Ensure the email is not the same as the parent's email
                if ( $post_email && $post_email !== $parent_email ) {
                    $emails[] = $post_email;
                }
            }
            wp_reset_postdata();
        }
    
        // Return unique emails only
        return array_unique( $emails );
    }

    public function get_etn_rsvp_counts($post_ids) {
        $posts = [];
        foreach ($post_ids as $post_id) {
            $posts[] = $post_id->ID;
        }
    
        // Initialize counters
        $counts = array(
            'going' => 0,
            'not going' => 0,
            'maybe' => 0,
        );
    
        if ($posts) {
            // Loop through each post ID
            foreach ($posts as $post_id) {
                // Get the RSVP value and number of attendees associated with the post
                $rsvp_value = get_post_meta($post_id, 'etn_rsvp_value', true);
                $number_of_attendees = get_post_meta($post_id, 'number_of_attendee', true);
    
                // Increment the corresponding counter
                if (isset($counts[$rsvp_value])) {
                    $counts[$rsvp_value] += $number_of_attendees;
                }
                if($rsvp_value == 'not_going') {
                    $counts['not going'] += $number_of_attendees;
                }
            }
    
            return $counts;
        }
    
        return $counts;
    }

    public function get_shortcode_values( $id ) {
        
        $location       = get_post_meta( $id, 'etn_event_location', true );
        $location       = isset( $location['address'] ) ? esc_attr( $location['address'] ) : '';
        $start_time     = get_post_meta( $id, 'etn_start_time', true );
        $end_time       = get_post_meta( $id, 'etn_end_time', true );
        $start_date     = get_post_meta( $id, 'etn_start_date', true );
        $end_date       = get_post_meta( $id, 'etn_end_date', true );
        $time           = esc_attr( $start_time ) .' - '. esc_attr( $end_time );
        $date           = esc_attr( $start_date ) .' - '. esc_attr( $end_date );
        $current_user   = wp_get_current_user();

        return [
            '{%site_name%}'         => get_bloginfo( 'name' ),
            '{%event_link%}'         => esc_url( get_permalink( $id ) ),
            '{%event_name%}'        => get_the_title( $id ),
            '{%event_date%}'        => $date,
            '{%event_time%}'        => $time,
            '{%event_location%}'    => $location,
            // '{%event_title%}'       => $get_the_title( $id ),
            // '{%host_name%}'         => $current_user->display_name,
            // '{%host_email%}'        => $current_user->user_email,
        ];
    }
    
    /**
     * Get placeholder values for the RSVP email.
     *
     * @param int $id The post ID of the event.
     * @return array An associative array of placeholder values.
     */
    public function get_placeholder_values( $id, $rsvp_email ) {

        $location       = get_post_meta( $id, 'etn_event_location', true );
        $location       = isset( $location['address'] ) ? esc_attr( $location['address'] ) : '';
        $start_time     = get_post_meta( $id, 'etn_start_time', true );
        $end_time       = get_post_meta( $id, 'etn_end_time', true );
        $start_date     = get_post_meta( $id, 'etn_start_date', true );
        $end_date       = get_post_meta( $id, 'etn_end_date', true );
        $date_format    = get_option( 'date_format' );
        $time_format    = get_option( 'time_format' );

        $start_dt   = new \DateTime( $start_date . ' ' . $start_time, wp_timezone() );
        $end_dt     = new \DateTime( $end_date . ' ' . $end_time, wp_timezone() );
        $time       = wp_date( $time_format, $start_dt->getTimestamp() ) . ' - ' . wp_date( $time_format, $end_dt->getTimestamp() );
        $date       = wp_date( $date_format, $start_dt->getTimestamp() ) . ' - ' . wp_date( $date_format, $end_dt->getTimestamp() );
        $current_user   = wp_get_current_user();

        $email_for_name = is_array( $rsvp_email ) ? reset( $rsvp_email ) : $rsvp_email;
        $rsvp_posts     = get_posts( [
            'post_type'      => 'etn_rsvp',
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'orderby'        => 'ID',
            'order'          => 'DESC',
            'meta_query'     => [
                'relation' => 'AND',
                [ 'key' => 'attendee_email', 'value' => $email_for_name ],
                [ 'key' => 'event_id',       'value' => $id ],
            ],
        ] );
        $attendee_name = ! empty( $rsvp_posts ) ? get_post_meta( $rsvp_posts[0]->ID, 'attendee_name', true ) : '';

        return [
            'site_name'      => get_bloginfo( 'name' ),
            'site_link'      => esc_url( get_permalink( $id ) ),
            'event_name'     => get_the_title( $id ),
            'event_date'     => $date,
            'event_time'     => $time,
            'event_location' => $location,
            'event_title'    => get_the_title( $id ),
            'host_name'      => $current_user->display_name,
            'host_email'     => $current_user->user_email,
            'attendee_email' => $rsvp_email,
            'attendee_name'  => $attendee_name,
        ];
    }
	
	
	/**
	 * RSVP exporter
	 *
	 * @param   WP_Request  $request
	 *
	 * @return  json
	 */
	public function export_items( $request ) {
		$format = ! empty( $request['format'] ) ? sanitize_text_field( $request['format'] ) : '';
		
		$ids    = ! empty( $request['ids'] ) ? $request['ids'] : [];
		$event_id  = ! empty( $request->get_param('event_id') ) ? $request->get_param('event_id') : 0;
		
		if ( ! $format ) {
			return new WP_Error( 'format_error', __( 'Invalid data format', 'eventin' ) );
		}
    

		try {
			$rsvpService = new RsvpService();
			$rsvps = $rsvpService->findAll($ids, $event_id);

			$exporter = new RsvpExporter();
			$exporter->export( $rsvps, $format );
		} catch (\Exception $exception) {
            
		}
	}
	
	/**
	 * Check export items permissions
	 *
	 * @param   WP_Rest_Request  $request  [$request description]
	 *
	 * @return  bool
	 */
	public function export_item_permissions_check( $request ) {
		return current_user_can( 'etn_manage_event' );
	}
	
	/**
	 * RSVP Importer
	 *
	 * @param   WP_Request  $request
	 *
	 * @return  json
	 */
	public function import_items( $request ) {
		$data = $request->get_file_params();
		$file = ! empty( $data['rsvp_import'] ) ? $data['rsvp_import'] : '';
		
		if ( ! $file ) {
			return new WP_Error( 'empty_file', __( 'You must provide a valid file.', 'eventin' ), ['status' => 409] );
		}
		
		$importer = new RsvpImporter();
		$importer->import( $file );
		
		$response = [
			'message' => __( 'Successfully imported attendee', 'eventin' ),
		];
		
		return rest_ensure_response( $response );
	}
	
	/**
	 * Check permissions for import attendees
	 *
	 * @param   WP_Rest_Request  $request  [$request description]
	 *
	 * @return  bool
	 */
	public function import_item_permissions_check( $request ) {
		return current_user_can( 'etn_manage_attendee' );
	}

    public function etn_rsvp_email_data($fields) {
		$event_id = $fields['event_id'];
		$event 	  = new Event_Model( $event_id );
		$post	  = get_post( $event_id );
		$location = get_post_meta( $event_id, 'etn_event_location', true );
		$address  = ! empty( $location['address'] ) ? $location['address'] : '';

		$admins 	= get_users(array('role' => 'administrator'));
		$host_name 	= '';
		$host_email = '';

		// Check if there are any administrators
		if (!empty($admins)) {
			// Get the first administrator's data (assuming the first one is the main admin)
			$admin = $admins[0];

			// Get the admin's email and display name
			$host_email = $admin->user_email;
			$host_name = $admin->display_name;
		}
		
		$placeholder = [
			'{%site_name%}' 	 => get_bloginfo( 'name' ),
			'{%site_link%}' 	 => site_url(),
			'{%site_logo%}' 	 => get_bloginfo('logo'),
			'{%event_title%}'    => $post->post_title,
			'{%event_date%}' 	 => $event->etn_start_date,
			'{%event_time%}' 	 => $event->etn_start_time,
			'{%event_location%}' => $address,
			'{%host_name%}' 	 => $host_name,
			'{%host_email%}'	 => $host_email,
		];

		$settings = etn_get_option();
		
		$email_body['email_message'] = [];
		$mail_to                     = array_unique( $fields['attendee_email'] );
		$form_data                   = [];
		$email_body                  = [];
		$email_body['event_id']      = $fields['event_id'];
		$admin_email                 = get_option( 'admin_email' );
		$from_name                   = get_option( 'blogname' );

		$rsvp_auto_confirm_send_email = isset( $settings['rsvp_auto_confirm_send_email'] ) ? 'checked' : '';
		$rsvp_auto_confirm = etn_get_option( 'rsvp_auto_confirm' ) ? 'checked' : '';

		$rsvp_email = etn_get_email_settings( 'rsv_email' );
		$message 	= ! empty( $rsvp_email['body'] ) ? $rsvp_email['body'] : '';
		$subject 	= ! empty( $rsvp_email['subject'] ) ? $rsvp_email['subject'] : esc_html__( 'We received your RSVP request', 'eventin-pro' );
		$from 	= ! empty( $rsvp_email['from'] ) ? $rsvp_email['from'] : $admin_email;
		$message = strtr( $message, $placeholder );
		
		if ( $rsvp_auto_confirm == 'checked' ) {
			$email_body['email_message'] = $message;
			$rsvp_status = 'approved';
		}
		else {
			$email_body['email_message'] = '';
			$rsvp_status = 'pending';
		}

		if ( ! empty( $mail_to ) ) {
			$form_data = [
				'email_body' => $email_body,
				'mail_to'    => $mail_to,
				'mail_from'  => $from,
				'type'       => $rsvp_status,
				'subject'    => $subject,
			];

            $etn_addons_options = get_option( 'etn_addons_options' ) ?? [];
            $is_automation_module_on = 'off';
			if ( is_array( $etn_addons_options ) ) {
				$is_automation_module_on = $etn_addons_options["automation"] ?? "off";
			}

			// check if automation module is on
			if ( 'on' === $is_automation_module_on ) {
                if(!empty($fields['attendee_email']) && !empty($fields['event_id']) ){
                    $base_placeholder = $this->get_placeholder_values($fields['event_id'], $fields['attendee_email']);
                    $base_placeholder['registration_time_timestamp'] = current_time('timestamp');

                    foreach ( $fields['attendee_email'] as $attendee_email ) {
                        $placeholder = $this->get_placeholder_values($fields['event_id'], $attendee_email);
                        $placeholder['registration_time_timestamp'] = $base_placeholder['registration_time_timestamp'];
                        $placeholder['session_id'] = uniqid();
                        do_action('global_notification_hook','event_rsvp_email',$placeholder);
                    }
                }
			}
            else{
                return  new \Etn_Pro\Core\Modules\Rsvp\Notifications\Rsvp_Response($form_data);
            }
		} 
	}
}
