<?php
/**
 * Webhook Admin
 *
 * @package EventinPro
 */
namespace Etn_Pro\Core\Webhook;

use Etn_Pro\Traits\Singleton;
use EventinPro\Webhook\Api\WebhookController;

/**
 * Class WebhookAdmin
 */
class Webhook_Admin {
    use Singleton;

    /**
     * Initalize for the Webhook_Admin
     *
     * @return void
     */
    public function init() {
        // Add webhook controller to main controllers.
        add_filter( 'eventin_api_controllers', [$this, 'add_webhook_controller'] );
    }

    public function add_webhook_controller( $controllers ) {
        $controllers[] = WebhookController::class;

        return $controllers;
    }
}
