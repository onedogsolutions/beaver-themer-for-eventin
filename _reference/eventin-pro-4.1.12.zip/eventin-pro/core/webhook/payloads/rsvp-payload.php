<?php
/**
 * RSVP Payload
 *
 * @package Eventin
 */
namespace Etn_Pro\Core\Webhook\Payloads;

/**
 * RSVP Payload Class
 */
class RsvpPayload implements PayloadInterface {
    /**
     * Get payload
     *
     * @param   int|\WP_Post  $arg  RSVP post id or WP_Post.
     *
     * @return  array|null
     */
    public function get_data( $arg ) {
        if ( is_object( $arg ) && ! empty( $arg->_eventin_rsvp_event ) ) {
            $data = (array) $arg;
            unset( $data['_eventin_rsvp_event'] );
            return $data;
        }

        $post = $arg instanceof \WP_Post ? $arg : get_post( intval( $arg ) );

        if ( ! $post || 'etn_rsvp' !== $post->post_type ) {
            return null;
        }

        $id       = $post->ID;
        $event_id = intval( get_post_meta( $id, 'event_id', true ) );

        return [
            'id'                    => $id,
            'event_id'              => $event_id,
            'event_name'            => $event_id ? get_the_title( $event_id ) : '',
            'status'                => get_post_meta( $id, 'etn_rsvp_value', true ),
            'number_of_attendee'    => intval( get_post_meta( $id, 'number_of_attendee', true ) ),
            'attendee_name'         => get_the_title( $id ),
            'attendee_email'        => get_post_meta( $id, 'attendee_email', true ),
            'attendee_phone'        => get_post_meta( $id, 'phone', true ),
            'attendee_extra_fields' => get_post_meta( $id, 'extra_fields', true ),
            'rsvp_not_going_reason' => get_post_meta( $id, 'rsvp_not_going_reason', true ),
            'received_on'           => $post->post_modified,
            'guests'                => $this->get_guests( $id ),
        ];
    }

    /**
     * Get child RSVP entries for a parent.
     *
     * @param   int  $parent_id
     *
     * @return  array
     */
    private function get_guests( $parent_id ) {
        $child_ids = get_posts( [
            'post_type'      => 'etn_rsvp',
            'post_parent'    => $parent_id,
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ] );

        return array_map( function( $cid ) {
            return [
                'id'    => $cid,
                'name'  => get_the_title( $cid ),
                'email' => get_post_meta( $cid, 'attendee_email', true ),
                'phone' => get_post_meta( $cid, 'phone', true ),
            ];
        }, $child_ids );
    }
}
