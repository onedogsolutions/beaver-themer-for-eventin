<?php
/**
 * Class stripe payment
 *
 * @package Timetics
 */
namespace EventinPro\Integrations\Stripe;

use Exception;

/**
 * Class Stripe
 */
class Stripe {
    /**
     * Store stripe paymentintent api url
     *
     * @var string
     */
    private $payment_intent_url = 'https://api.stripe.com/v1/payment_intents';

    /**
     * Store stripe secreate key
     *
     * @var string
     */
    private $secret_key;

    public function __construct( $secret_key = null ) {
        if ( ! $secret_key ) {
            throw new Exception( 'You must provide stripe secret key' );
        }

        $this->secret_key = $secret_key;
    }

    /**
     * Create stripe paymentintent
     *
     * @param   array  $args  Stripe payment details
     *
     * @return  array
     */
    public function create_payment( $args = [] ) {
        $defaults = [
            'amount'                 => 0,
            'currency'               => '',
            'automatic_payment_methods' => ['enabled' => "true"],
        ];

        $args   = wp_parse_args( $args, $defaults );

        $zero_decimal_currencies = [
            'JPY',
            'KRW',
            'VND',
            'IRR',
            'IDR',
            'COP',
            'CLP',
            'PYG',
        ];
        
        if ( ! in_array( $args['currency'], $zero_decimal_currencies ) ) {
            $args['amount'] = $args['amount'] * 100;
        }

        $url    = $this->payment_intent_url;
        $secret = $this->secret_key;

        $params = [
            'headers' => [
                'Authorization' => 'Bearer ' . $secret,
                'Content-Type'  => 'application/x-www-form-urlencoded;charset=UTF-8',
            ],
            'body'    => build_query( $args ),
        ];

        $response = wp_remote_post( $url, $params );

        if ( 200 === wp_remote_retrieve_response_code( $response ) ) {
            $data = json_decode( wp_remote_retrieve_body( $response ), true );
            
            return [
                'id'            => $data['id'],
                'client_secret' => $data['client_secret'],
            ];
        }

        return $response;
    }

    /**
     * Create fund
     *
     * @return
     */
    public function create_refund( $payment_intent_id ) {
        $api_url = 'https://api.stripe.com/v1/refunds';

        $args = [
            'payment_intent' => $payment_intent_id,
        ];

        $params = [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->secret_key,
                'Content-Type'  => 'application/x-www-form-urlencoded;charset=UTF-8',
            ],
            'body'    => build_query( $args ),
        ];

        $response = wp_remote_post( $api_url, $params );
        
        return 200 == wp_remote_retrieve_response_code( $response );
    }

    /**
     * Verify Stripe webhook signature
     *
     * @param string $payload Raw request body
     * @param string $sig_header Stripe-Signature header value
     * @param string $secret Webhook signing secret
     * @return bool True if signature is valid
     */
    public static function verify_webhook_signature( $payload, $sig_header, $secret ) {
        if ( empty( $payload ) || empty( $sig_header ) || empty( $secret ) ) {
            return false;
        }

        $elements = explode( ',', $sig_header );
        $signed_properties = [];

        foreach ( $elements as $element ) {
            $parts = explode( '=', $element, 2 );
            if ( count( $parts ) === 2 ) {
                $signed_properties[ $parts[0] ] = $parts[1];
            }
        }

        if ( ! isset( $signed_properties['t'] ) || ! isset( $signed_properties['v1'] ) ) {
            return false;
        }

        $timestamp = $signed_properties['t'];
        $signature = $signed_properties['v1'];

        $tolerance = 300;
        if ( abs( time() - $timestamp ) > $tolerance ) {
            return false;
        }

        $signed_payload = $timestamp . '.' . $payload;
        $expected_signature = hash_hmac( 'sha256', $signed_payload, $secret );

        return hash_equals( $expected_signature, $signature );
    }
	
}
