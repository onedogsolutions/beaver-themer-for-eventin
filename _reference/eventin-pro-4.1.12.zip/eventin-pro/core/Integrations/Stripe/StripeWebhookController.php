<?php
/**
 * Stripe Webhook Controller
 *
 * @package EventinPro\Integrations\Stripe
 */

namespace EventinPro\Integrations\Stripe;

use WP_Error;
use WP_REST_Controller;
use WP_REST_Server;
use Eventin\Order\OrderModel;

/**
 * Stripe Webhook Controller Class
 */
class StripeWebhookController extends WP_REST_Controller {

    /**
     * Constructor for StripeWebhookController
     *
     * @return void
     */
    public function __construct() {
        $this->namespace = 'eventin/v2';
        $this->rest_base = 'stripe-webhook';
    }

    /**
     * Register the webhook route
     *
     * @return void
     */
    public function register_routes() {
        register_rest_route(
            $this->namespace,
            $this->rest_base,
            [
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [ $this, 'handle_webhook' ],
                    'permission_callback' => '__return_true',
                ],
            ]
        );
    }

    /**
     * Handle incoming Stripe webhook
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function handle_webhook( $request ) {
        $payload     = $request->get_body();
        $sig_header  = $request->get_header( 'Stripe-Signature' );
        $secret      = etn_get_option( 'etn_stripe_webhook_secret' );

        if ( ! $secret ) {
            return new WP_Error(
                'webhook_secret_missing',
                'Stripe webhook secret is not configured',
                [ 'status' => 400 ]
            );
        }

        if ( empty(Stripe::verify_webhook_signature( $payload, $sig_header, $secret )) ) {
            return new WP_Error(
                'invalid_signature',
                'Invalid Stripe webhook signature',
                [ 'status' => 400 ]
            );
        }

        $event = json_decode( $payload, true );

        if ( ! $event || ! isset( $event['type'] ) ) {
            return new WP_Error(
                'invalid_payload',
                'Invalid webhook payload',
                [ 'status' => 400 ]
            );
        }

        switch ( $event['type'] ) {
            case 'payment_intent.succeeded':
                $this->handle_payment_succeeded( $event['data']['object'] );
                break;
            case 'payment_intent.payment_failed':
                $this->handle_payment_failed( $event['data']['object'] );
                break;
            case 'charge.refunded':
                $this->handle_refund( $event['data']['object'] );
                break;
            default:
                break;
        }

        return rest_ensure_response( [ 'received' => true ] );
    }

    /**
     * Find order by payment intent ID
     *
     * @param string $payment_intent_id Stripe payment intent ID.
     * @return OrderModel|null
     */
    private function find_order_by_payment_id( $payment_intent_id ) {
        $args = [
            'post_type'   => 'etn-order',
            'post_status' => 'any',
            'posts_per_page' => 1,
            'fields'     => 'ids',
            'meta_query' => [
                [
                    'key'   => 'payment_id',
                    'value' => $payment_intent_id,
                    'compare' => '=',
                ],
            ],
        ];

        $query = new \WP_Query( $args );

        if ( ! $query->posts ) {
            return null;
        }

        return new OrderModel( $query->posts[0] );
    }

    /**
     * Handle successful payment
     *
     * @param array $payment_intent Stripe payment intent data.
     * @return void
     */
    private function handle_payment_succeeded( $payment_intent ) {
        $order = $this->find_order_by_payment_id( $payment_intent['id'] );

        if ( ! $order || 'completed' === $order->status ) {
            return;
        }

        $order->update( [ 'status' => 'completed' ] );
        do_action( 'eventin_order_completed', $order );
        $order->send_email();
    }

    /**
     * Handle failed payment
     *
     * @param array $payment_intent Stripe payment intent data.
     * @return void
     */
    private function handle_payment_failed( $payment_intent ) {
    $order = $this->find_order_by_payment_id( $payment_intent['id'] );

        if ( ! $order ) {
            return;
        }

        $status = $order->status;
        if ( in_array( $status, [ 'completed', 'failed' ], true ) ) {
            return;
        }

        $order->update( [ 'status' => 'failed' ] );
        do_action( 'eventin_order_status_failed', $order );
    }

    /**
     * Handle refund
     *
     * @param array $charge Stripe charge data.
     * @return void
     */
    private function handle_refund( $charge ) {
        if ( ! isset( $charge['payment_intent'] ) ) {
            return;
        }

        $order = $this->find_order_by_payment_id( $charge['payment_intent'] );

        if ( ! $order || 'refunded' === $order->status ) {
            return;
        }

        $order->update( [ 'status' => 'refunded' ] );
        do_action( 'eventin_order_refund', $order, $order );
    }
}
