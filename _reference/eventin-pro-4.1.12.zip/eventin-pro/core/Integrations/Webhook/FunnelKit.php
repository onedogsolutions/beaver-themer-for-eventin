<?php

/**
 * FunnelKit Automations integration (Pro)
 *
 * @package EventinPro
 */
namespace EventinPro\Integrations\Webhook;

defined( 'ABSPATH' ) || exit;

use Eventin\Integrations\Webhook\WebhookIntegrationInterface;
use Eventin\Order\OrderModel;

/**
 * FunnelKit Automations webhook integration
 */
class FunnelKit implements WebhookIntegrationInterface {
    /**
     * Hook into the order-create action
     *
     * @return  void
     */
    public function run() {
        add_action( 'eventin_after_order_create', [ $this, 'send_data_to_funnelkit' ], 10, 2 );
    }

    /**
     * Dispatch on order create
     *
     * @param   OrderModel  $order
     * @param   array       $attendees
     *
     * @return  void
     */
    public function send_data_to_funnelkit( $order, $attendees ) {
        $this->send_data( $order, $attendees );

        $attendee_registration = 'on' === etn_get_option( 'attendee_registration' );

        if ( $attendee_registration ) {
            try {
                foreach ( $attendees as $attendee ) {
                    $this->send_attendee_data( $order, $attendee );
                }
            } catch ( \Exception $exception ) {
            }
        }
    }

    /**
     * Send purchaser data to FunnelKit webhook
     *
     * @param   OrderModel  $order
     * @param   array       $attendees
     *
     * @return  void
     */
    public function send_data( $order, $attendees = [] ) {
        $event_id = $order->event_id;

        if ( ! $this->is_enabled( $event_id ) ) {
            return;
        }

        $send_to = $this->get_send_to( $event_id );

        if ( ! in_array( 'purchaser', $send_to, true ) ) {
            return;
        }

        $body = [
            'email'      => $order->customer_email,
            'first_name' => $order->customer_fname,
            'last_name'  => $order->customer_lname,
        ];

        $body = apply_filters( 'eventin_funnelkit_purchaser_data', $body, $order, $attendees );

        $this->post_to_webhook( $this->get_webhook( $event_id ), $body, 'purchaser' );
    }

    /**
     * Send individual attendee data to FunnelKit webhook
     *
     * @param   OrderModel  $order
     * @param   array       $attendee
     *
     * @return  void
     */
    public function send_attendee_data( OrderModel $order, $attendee ): void {
        $event_id = $order->event_id;

        if ( ! $this->is_enabled( $event_id ) ) {
            return;
        }

        $send_to = $this->get_send_to( $event_id );

        if ( ! in_array( 'attendee', $send_to, true ) ) {
            return;
        }

        $name              = isset( $attendee['etn_name'] ) ? trim( (string) $attendee['etn_name'] ) : '';
        list( $first, $last ) = $this->split_name( $name );

        $body = [
            'email'      => $attendee['etn_email'] ?? '',
            'first_name' => $first,
            'last_name'  => $last,
        ];

        $body = apply_filters( 'eventin_funnelkit_attendee_data', $body, $order, $attendee );

        $this->post_to_webhook( $this->get_webhook( $event_id ), $body, 'attendee' );
    }

    /**
     * Split a single-field display name into [first, last] on first whitespace
     *
     * @param   string  $name
     *
     * @return  array
     */
    private function split_name( $name ) {
        if ( '' === $name ) {
            return [ '', '' ];
        }

        $parts = preg_split( '/\s+/', $name, 2 );

        return [
            $parts[0] ?? '',
            $parts[1] ?? '',
        ];
    }

    /**
     * Check FunnelKit enabled for event and webhook present
     *
     * @param   int  $event_id
     *
     * @return  bool
     */
    private function is_enabled( $event_id ) {
        $extension_status = etn_get_option( 'funnel_kit_api' );
        $extension_on     = $extension_status && 'off' !== $extension_status;

        $event_enabled = 'yes' === get_post_meta( $event_id, 'funnel_kit', true );
        $webhook       = get_post_meta( $event_id, 'funnel_kit_webhook', true );

        return $extension_on && $event_enabled && ! empty( $webhook );
    }

    /**
     * Get webhook URL for event
     *
     * @param   int  $event_id
     *
     * @return  string
     */
    private function get_webhook( $event_id ) {
        return get_post_meta( $event_id, 'funnel_kit_webhook', true );
    }

    /**
     * Get send_to recipients for event
     *
     * @param   int  $event_id
     *
     * @return  array
     */
    private function get_send_to( $event_id ) {
        $send_to = get_post_meta( $event_id, 'funnel_kit_send_to', true );

        if ( empty( $send_to ) || ! is_array( $send_to ) ) {
            return [ 'purchaser', 'attendee' ];
        }

        return $send_to;
    }

    /**
     * POST body to FunnelKit webhook with local-host SSL allowance and error logging
     *
     * @param   string  $url
     * @param   array   $body
     * @param   string  $context  purchaser|attendee
     *
     * @return  void
     */
    private function post_to_webhook( $url, $body, $context ) {
        $args = [
            'body'      => $body,
            'timeout'   => 15,
            'sslverify' => $this->should_verify_ssl( $url ),
        ];

        $response = wp_remote_post( $url, $args );

        if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
            return;
        }

        if ( is_wp_error( $response ) ) {
            error_log( sprintf( '[Eventin Pro FunnelKit] %s POST error: %s', $context, $response->get_error_message() ) );
            return;
        }

        $code = wp_remote_retrieve_response_code( $response );

        if ( $code < 200 || $code >= 300 ) {
            error_log( sprintf(
                '[Eventin Pro FunnelKit] %s POST non-2xx (%d): %s',
                $context,
                $code,
                wp_remote_retrieve_body( $response )
            ) );
        }
    }

    /**
     * Skip SSL verification for local development hosts (e.g. *.local, localhost)
     *
     * @param   string  $url
     *
     * @return  bool
     */
    private function should_verify_ssl( $url ) {
        $host = wp_parse_url( $url, PHP_URL_HOST );

        if ( ! $host ) {
            return true;
        }

        if ( 'localhost' === $host || '127.0.0.1' === $host ) {
            return false;
        }

        if ( substr( $host, -6 ) === '.local' || substr( $host, -5 ) === '.test' ) {
            return false;
        }

        return true;
    }
}
