<?php

/**
 * Zoho CRM webhook integration (Pro)
 *
 * @package EventinPro
 */
namespace EventinPro\Integrations\Webhook;

defined( 'ABSPATH' ) || exit;

use Eventin\Integrations\Webhook\WebhookIntegrationInterface;
use Eventin\Order\OrderModel;

/**
 * Zoho CRM webhook integration
 *
 * Sends ticket purchaser and attendee data to a per-event Zoho Flow webhook URL.
 * Activated when the "zoho_crm" extension is on in Eventin → Extensions, and the
 * event has both `zoho_crm` post meta set to "yes" and a non-empty `zoho_crm_webhook`.
 */
class ZohoCRM implements WebhookIntegrationInterface {

    /**
     * Hook into the order-create action.
     *
     * @return void
     */
    public function run() {
        add_action( 'eventin_after_order_create', [ $this, 'send_data_to_zoho' ], 10, 2 );
    }

    /**
     * Dispatch on order create.
     *
     * @param OrderModel $order
     * @param array      $attendees
     *
     * @return void
     */
    public function send_data_to_zoho( $order, $attendees ) {
        $this->send_data( $order, $attendees );

        $attendee_registration = 'on' === etn_get_option( 'attendee_registration' );

        if ( $attendee_registration && is_array( $attendees ) ) {
            try {
                foreach ( $attendees as $attendee ) {
                    $this->send_attendee_data( $order, $attendee );
                }
            } catch ( \Exception $exception ) {
                // Match other CRM integrations: swallow webhook errors so order completion never blocks.
            }
        }
    }

    /**
     * Build and dispatch the purchaser payload.
     *
     * @param OrderModel $order
     * @param array      $attendees
     *
     * @return void
     */
    public function send_data( $order, $attendees = [] ) {
        $event_id = $order->event_id;

        if ( ! $this->is_enabled( $event_id ) ) {
            return;
        }

        $body = [
            'email'       => $order->customer_email,
            'first_name'  => $order->customer_fname,
            'last_name'   => $order->customer_lname,
            'phone'       => $order->customer_phone,
            'event_id'    => $event_id,
            'event_title' => get_the_title( $event_id ),
            'order_id'    => $order->id,
            'order_total' => $order->total_price,
            'lead_source' => 'Eventin',
        ];

        $body = apply_filters( 'eventin_zoho_purchaser_data', $body, $order, $attendees );

        $this->post_to_webhook( $this->get_webhook( $event_id ), $body, 'purchaser' );
    }

    /**
     * Build and dispatch a single attendee payload.
     *
     * @param OrderModel $order
     * @param array      $attendee
     *
     * @return void
     */
    public function send_attendee_data( OrderModel $order, $attendee ): void {
        $event_id = $order->event_id;

        if ( ! $this->is_enabled( $event_id ) ) {
            return;
        }

        $body = [
            'email'       => isset( $attendee['etn_email'] ) ? $attendee['etn_email'] : '',
            'first_name'  => isset( $attendee['etn_name'] ) ? $attendee['etn_name'] : '',
            'event_id'    => $event_id,
            'event_title' => get_the_title( $event_id ),
            'order_id'    => $order->id,
            'lead_source' => 'Eventin',
        ];

        $body = apply_filters( 'eventin_zoho_attendee_data', $body, $order, $attendee );

        $this->post_to_webhook( $this->get_webhook( $event_id ), $body, 'attendee' );
    }

    /**
     * Extension is on, event opted-in, and webhook URL present.
     *
     * @param int $event_id
     *
     * @return bool
     */
    private function is_enabled( $event_id ) {
        $extension_status = etn_get_option( 'zoho_crm_api' );
        $extension_on     = $extension_status && 'off' !== $extension_status;

        $event_enabled = 'yes' === get_post_meta( $event_id, 'zoho_crm', true );
        $webhook       = get_post_meta( $event_id, 'zoho_crm_webhook', true );

        return $extension_on && $event_enabled && ! empty( $webhook );
    }

    /**
     * Webhook URL for the event.
     *
     * @param int $event_id
     *
     * @return string
     */
    private function get_webhook( $event_id ) {
        return get_post_meta( $event_id, 'zoho_crm_webhook', true );
    }

    /**
     * POST body to the Zoho Flow webhook. Loose SSL on local hosts so dev sites work.
     *
     * @param string $url
     * @param array  $body
     * @param string $context  purchaser|attendee
     *
     * @return void
     */
    private function post_to_webhook( $url, $body, $context ) {
        $args = [
            'body'      => $body,
            'timeout'   => 15,
            'sslverify' => $this->should_verify_ssl( $url ),
        ];

        $response = wp_remote_post( $url, $args );

        if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
            return;
        }

        if ( is_wp_error( $response ) ) {
            error_log( sprintf( 'ZohoCRM (%s) webhook failed: %s', $context, $response->get_error_message() ) );
        }
    }

    /**
     * Skip SSL verification only for local-host URLs. Production traffic always verifies.
     *
     * @param string $url
     *
     * @return bool
     */
    private function should_verify_ssl( $url ) {
        $host = wp_parse_url( $url, PHP_URL_HOST );

        if ( ! $host ) {
            return true;
        }

        $local_hosts = [ 'localhost', '127.0.0.1', '::1' ];

        if ( in_array( $host, $local_hosts, true ) ) {
            return false;
        }

        if ( preg_match( '/\.(local|test|localhost)$/i', $host ) ) {
            return false;
        }

        return true;
    }
}
