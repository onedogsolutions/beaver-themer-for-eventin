<?php
// Enqueue Elementor styles if template is built with Elementor.
if ( did_action( 'elementor/loaded' ) && ! empty( $page_id ) ) {
    $document = \Elementor\Plugin::$instance->documents->get( $page_id );
    if ( $document && $document->is_built_with_elementor() ) {
        \Elementor\Plugin::$instance->frontend->enqueue_styles();
        $css_file = \Elementor\Core\Files\CSS\Post::create( $page_id );
        $css_file->enqueue();
    }
}

wp_head();

// Required scripts to generate Certificate PDF (enqueue before wp_head so scripts are printed)
wp_enqueue_script('etn-html-2-canvas');
wp_enqueue_script('etn-pdf-gen');
wp_enqueue_script('etn-dom-purify-pdf');


?>

<!-- Viewport meta overwritten because of pdf layout. It should not be changed even in mobile device. -->
<meta name="viewport" content="width=900 initial-scale=1">

<!-- Layout wrapper -->
<div class="etn-certificate-container">

    <div class="eventin-container-block" id="etn-pdf-container">
        <?php echo $certificate_content ?>
    </div>
    <div class="etn-control-header">
        <button id="etn-certificate-download" class="etn-certificate-download etn-btn">
            <?php echo esc_html__('Download Certificate', 'eventin-pro'); ?>
        </button>
    </div>

</div>
<!-- Layout wrapper end -->
<?php     
    wp_footer();
?>