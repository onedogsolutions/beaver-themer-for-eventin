<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Event_Schedule_Tab extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'event-schedule-tab'; // Make sure to prefix your elements
  public $icon         = 'ti-agenda'; // Themify icon font class
  public $css_selector = '.event-schedule'; // Default CSS selector
  public $scripts      = ['schedule']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Eventin Schedule Tab', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['eventin_event_schedule_tab'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Event schedule Tab', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {

    $this->controls['select_schedule'] = [
      'tab'      => 'content',
      'label'    => esc_html__( 'Select Schedule', 'eventin-bricks-addon' ),
      'type'     => 'select',
      'multiple' => true,
      'options'  => $this->get_schedules(),
      'group'    => 'eventin_event_schedule_tab',
    ];

    $this->controls['event_schedule_order'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Select Order', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'DESC'      => esc_html__( 'DESC', 'eventin-bricks-addon' ),
        'ASC'       => esc_html__( 'ASC', 'eventin-bricks-addon' )
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'DESC', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'DESC',
      'group'       => 'eventin_event_schedule_tab',
    ];

  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'schedule' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[]       = 'event-schedule';
    $select_schedule      = isset( $this->settings['select_schedule']) ? ($this->settings['select_schedule']): '';
    $event_schedule_order = $this->settings['event_schedule_order'];
    
    if (is_array($select_schedule)) {
      $select_schedule_item = implode(", ", $select_schedule);
    } else {
      $select_schedule_item = (string)$select_schedule;
    }

    // Render element HTML
    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
      echo do_shortcode("[schedules order='$event_schedule_order' ids ='$select_schedule_item']");
    echo '</div>';
  }

  public function get_schedules(){
      return Helper::get_schedules();
  }


}