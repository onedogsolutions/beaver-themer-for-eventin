<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Event_Ticket_Form extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'event_ticket_form'; // Make sure to prefix your elements
  public $icon         = 'ti-id-badge'; // Themify icon font class
  public $css_selector = '.etn-ticket-form'; // Default CSS selector
  public $scripts      = ['ticket-form']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Event Ticket Form (Pro)', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['event_ticket_form'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Event Ticket Form', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {

    $this->controls['event_list'] = [
      'tab'      => 'content',
      'label'    => esc_html__( 'Select Event', 'eventin-bricks-addon' ),
      'type'     => 'select',
      'multiple' => false,
      'options'  => $this->get_events(),
      'group'    => 'event_ticket_form',
    ];

    $this->controls['show_title'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Show Title', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'no'        => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'       => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'No', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'no',
      'group'       => 'event_ticket_form',
    ];
  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'prefix-test-script' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[] = 'prefix-test-wrapper';
    $show_title = $this->settings['show_title'];
    $event_list = isset($this->settings['event_list']) ? ($this->settings['event_list']) : '';

    // event cats
    if (is_array($event_list)) {
      $event_list = implode(", ", $event_list);
    } else {
      $event_list = (string)$event_list;
    }

    
    if ( ! empty( $this->settings['type'] ) ) {
      $root_classes[] = "color-{$this->settings['type']}";
    }

    // Add 'class' attribute to element root tag
    $this->set_attribute( '_root', 'class', $root_classes );

    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
    echo do_shortcode("[etn_pro_ticket_form id = '$event_list' show_title='$show_title']");
    echo '</div>';
  }

  public function get_events(){
      return Helper::get_events();
  }

}