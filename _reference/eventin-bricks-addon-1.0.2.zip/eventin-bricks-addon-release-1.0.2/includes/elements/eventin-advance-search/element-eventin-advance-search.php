<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Eventin_Advance_Search extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'eventin-advance-search'; // Make sure to prefix your elements
  public $icon         = 'ti-search'; // Themify icon font class
  public $css_selector = '.eventin-search'; // Default CSS selector
  public $scripts      = ['advance-search']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Eventin Advance Search', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['eventin_advance_search'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Eventin Advance Search', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {

  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'advance-search' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[] = 'eventin-search';
    // '_root' attribute is required since Bricks 1.4 (contains element ID, class, etc.)
    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
      echo do_shortcode("[event_search_filter]");
    echo '</div>';
  }
}