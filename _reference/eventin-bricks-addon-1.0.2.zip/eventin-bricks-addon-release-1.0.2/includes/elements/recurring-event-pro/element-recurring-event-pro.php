<?php

use Etn\Utils\Helper;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

class Etn_Recurring_Event_Pro extends \Bricks\Element
{
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'recurring-event-pro'; // Make sure to prefix your elements
  public $icon         = 'fa-solid fa-arrow-down-wide-short'; // Themify icon font class
  public $css_selector = '.etn-attendee-list'; // Default CSS selector
  public $scripts      = ['attendee-list']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label()
  {
    return esc_html__('Recurring Event (Pro)', 'eventin-bricks-addon');
  }

  // Set builder control groups
  public function set_control_groups()
  {
    $this->control_groups['eventin_attendee'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__('Attendee List', 'eventin-bricks-addon'), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }

  // Set builder controls
  public function set_controls()
  {

    $this->controls['single_event_ids'] = [
      'tab' => 'content',
      'label' => esc_html__('Select Event', 'eventin-bricks-addon'),
      'type' => 'select',
      'multiple'    => false,
      'options' => $this->get_events(),
      'group' => 'eventin_attendee',
    ];
  }

  // Enqueue element styles and scripts
  public function enqueue_scripts()
  {
    wp_enqueue_script('prefix-test-script');
  }

  // Render element HTML
  public function render()
  {
    // Set element attributes
    $root_classes[] = 'prefix-test-wrapper';
    $event_item = !empty($this->settings['single_event_ids']) ? $this->settings['single_event_ids'] : '';


    if (! empty($this->settings['type'])) {
      $root_classes[] = "color-{$this->settings['type']}";
    }

    // Add 'class' attribute to element root tag
    $this->set_attribute('_root', 'class', $root_classes);

    // Render element HTML
    echo "<div {$this->render_attributes('_root')}>"; // Element root attributes
    echo do_shortcode("[etn_event_recurring single_event_ids ='$event_item']");
    echo '</div>';
  }

  public function get_events()
  {
    return Helper::get_events();
  }
}
