<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Event_List extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'event-list'; // Make sure to prefix your elements
  public $icon         = 'ti-view-list-alt'; // Themify icon font class
  public $css_selector = '.event-list'; // Default CSS selector
  public $scripts      = ['eventList']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Event List', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['eventin_event'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Eventin Event', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {
    $this->controls['event_style'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Select Style', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'event-1'   => esc_html__( 'Style 1', 'eventin-bricks-addon' ),
        'event-2'   => esc_html__( 'Style 2', 'eventin-bricks-addon' ),
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'Select Style', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'event-1',
      'group'       => 'eventin_event',
    ];

    $this->controls['select_cats'] = [
      'tab'      => 'content',
      'label'    => esc_html__( 'Select Category', 'eventin-bricks-addon' ),
      'type'     => 'select',
      'multiple' => true,
      'options'  => $this->get_event_category(),
      'group'    => 'eventin_event',
    ];

    $this->controls['select_tags'] = [
      'tab'      => 'content',
      'label'    => esc_html__( 'Select Tags', 'eventin-bricks-addon' ),
      'type'     => 'select',
      'multiple' => true,
      'options'  => $this->get_event_tag(),
      'group'    => 'eventin_event',
    ];
   
    $this->controls['event_order'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Select Order', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'DESC'      => esc_html__( 'DESC', 'eventin-bricks-addon' ),
        'ASC'       => esc_html__( 'ASC', 'eventin-bricks-addon' )
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'DESC', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'DESC',
      'group'       => 'eventin_event',
    ];
    $this->controls['event_orderby'] = [
      'tab'              => 'content',
      'label'            => esc_html__( 'Select Orderby', 'eventin-bricks-addon' ),
      'type'             => 'select',
      'options'          => [
        'title'          => esc_html__( 'Title', 'eventin-bricks-addon' ),
        'ID'             => esc_html__( 'ID', 'eventin-bricks-addon' ),
        'post_date'      => esc_html__( 'Post Date', 'eventin-bricks-addon' ),
        'etn_start_date' => esc_html__( 'Event Start Date', 'eventin-bricks-addon' ),
        'etn_end_date'   => esc_html__( 'Event End Date', 'eventin-bricks-addon' ),
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'ID', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'ID',
      'group'       => 'eventin_event',
    ];
    $this->controls['event_filter'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Filter by status', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'all'       => esc_html__( 'All', 'eventin-bricks-addon' ),
        'upcoming'  => esc_html__( 'Upcoming', 'eventin-bricks-addon' ),
        'expire'    => esc_html__( 'Expire', 'eventin-bricks-addon' ),
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'Upcoming', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'all',
      'group'       => 'eventin_event',
    ];
    $this->controls['event_column'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Event Column', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        '1'         => esc_html__( 'Column 1', 'eventin-bricks-addon' ),
        '2'         => esc_html__( 'Column 2', 'eventin-bricks-addon' ),
        '3'         => esc_html__( 'Column 3', 'eventin-bricks-addon' ),
        '4'         => esc_html__( 'Column 4', 'eventin-bricks-addon' ),
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'Column 1', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => '1',
      'group'       => 'eventin_event',
    ];
    $this->controls['event_limit'] = [
      'tab'     => 'content',
      'group'   => 'eventin_event',
      'label'   => esc_html__( 'Event Limit', 'eventin-bricks-addon' ),
      'type'    => 'number',
      'min'     => 0,
      'inline'  => true,
      'default' => 20,
    ];
    $this->controls['show_end_date'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Show End Date', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'no'        => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'       => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'No', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'no',
      'group'       => 'eventin_event',
    ];
    $this->controls['recurring_child_event'] = [
      'tab'       => 'content',
      'label'     => esc_html__( 'Show Recurring Child Events', 'eventin-bricks-addon' ),
      'type'      => 'select',
      'options'   => [
        'no'      => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'     => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'    => true,
      'clearable' => true,
      'default'   => 'no',
      'group'     => 'eventin_event',
    ];
    $this->controls['recurring_parent_event'] = [
      'tab'       => 'content',
      'label'     => esc_html__( 'Show Recurring Parent Events', 'eventin-bricks-addon' ),
      'type'      => 'select',
      'options'   => [
        'no'      => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'     => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'    => true,
      'clearable' => true,
      'default'   => 'yes',
      'group'     => 'eventin_event',
    ];
    $this->controls['event_location'] = [
      'tab'       => 'content',
      'label'     => esc_html__( 'Show Event Location', 'eventin-bricks-addon' ),
      'type'      => 'select',
      'options'   => [
        'no'      => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'     => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'    => true,
      'clearable' => true,
      'default'   => 'no',
      'group'     => 'eventin_event',
    ];
    
    $this->controls['etn_desc_show'] = [
      'tab'       => 'content',
      'label'     => esc_html__( 'Show Event Description', 'eventin-bricks-addon' ),
      'type'      => 'select',
      'options'   => [
        'no'      => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'     => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'    => true,
      'clearable' => true,
      'default'   => 'no',
      'group'     => 'eventin_event',
    ];
  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'prefix-test-script' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[]         = 'prefix-test-wrapper';
    $event_style            = $this->settings['event_style'];
    
    $order                  = $this->settings['event_order'];
    $orderby                = $this->settings['event_orderby'];
    
    $event_column           = $this->settings['event_column'];
    $limit                  = $this->settings['event_limit'];
    $show_end_date          = $this->settings['show_end_date'];
    $recurring_child_event  = $this->settings['recurring_child_event'];
    $recurring_parent_event = $this->settings['recurring_parent_event'];
    $event_location         = $this->settings['event_location'];
    $etn_desc_show          = $this->settings['etn_desc_show'];
    $filter_with_status     = $this->settings['event_filter'];

    if($filter_with_status == 'all') {
      $filter_with_status = '';
    }

    $event_cats_list = isset($this->settings['select_cats']) ? ($this->settings['select_cats']) : '';
    $event_tags_list = isset($this->settings['select_tags']) ? ($this->settings['select_tags']) : '';

    // event cats
    if (is_array($event_cats_list)) {
      $event_cats = implode(", ", $event_cats_list);
    } else {
      $event_cats = (string)$event_cats_list;
    }

    // event tags
    if (is_array($event_tags_list)) {
      $event_tags = implode(", ", $event_tags_list);
    } else {
      $event_tags = (string)$event_tags_list;
    }
    
    
    if ( ! empty( $this->settings['type'] ) ) {
      $root_classes[] = "color-{$this->settings['type']}";
    }
    
    // Add 'class' attribute to element root tag
    $this->set_attribute( '_root', 'class', $root_classes );
  

    // Render element HTML
    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes

      echo do_shortcode("[events style ='$event_style' event_cat_ids ='$event_cats' event_tag_ids = '$event_tags' order='$order' orderby='$orderby' filter_with_status='$filter_with_status' etn_event_col ='$event_column' limit ='$limit' show_end_date='$show_end_date' show_child_event='$recurring_child_event' show_parent_event='$recurring_parent_event' show_event_location='$event_location' etn_desc_show='$etn_desc_show']");
    echo '</div>';
  }

  public function get_event_category(){
      return Helper::get_event_category();
  }

  public function get_event_tag(){
      return Helper::get_event_tag();
  }

}