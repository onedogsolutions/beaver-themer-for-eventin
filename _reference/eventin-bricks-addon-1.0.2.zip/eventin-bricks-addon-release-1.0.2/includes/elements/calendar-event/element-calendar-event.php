<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Event_Calendar extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'event-calendar-2'; // Make sure to prefix your elements
  public $icon         = 'ti-calendar'; // Themify icon font class
  public $css_selector = '.calendar-event'; // Default CSS selector
  public $scripts      = ['calendar-event']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Event Calendar  ', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['eventin_calendar'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Eventin Calendar Event', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content',
    ];
  }
 
  // Set builder controls
  public function set_controls() {
    $this->controls['calendar_event_style'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Select Style', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'style-1'   => esc_html__( 'Style 1', 'eventin-bricks-addon' ),
        'style-2'   => esc_html__( 'Style 2', 'eventin-bricks-addon' ),
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'Select Style', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'style-1',
      'group'       => 'eventin_calendar',
    ];

    $this->controls['calendar_display_style'] = [
      'tab'          => 'content',
      'label'        => esc_html__( 'Select Style', 'eventin-bricks-addon' ),
      'type'         => 'select',
      'options'      => [
        'left'       => esc_html__( 'Left', 'eventin-bricks-addon' ),
        'full_width' => esc_html__( 'Full Width', 'eventin-bricks-addon' ),
        'right'      => esc_html__( 'Right', 'eventin-bricks-addon' ),
      ],
      'inline'       => true,
      'placeholder'  => esc_html__( 'Select Style', 'eventin-bricks-addon' ),
      'clearable'    => true,
      'default'      => 'full_width',
      'group'        => 'eventin_calendar',
    ];

    $this->controls['select_cats'] = [
      'tab'      => 'content',
      'label'    => esc_html__( 'Select Category', 'eventin-bricks-addon' ),
      'type'     => 'select',
      'multiple' => true,
      'options'  => $this->get_event_category(),
      'group'    => 'eventin_calendar',
    ];

    $this->controls['show_event_desc'] = [
      'tab'       => 'content',
      'label'     => esc_html__( 'Show Event Desc', 'eventin-bricks-addon' ),
      'type'      => 'select',
      'options'   => [
        'no'      => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'     => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'    => true,
      'clearable' => true,
      'default'   => 'no',
      'group'     => 'eventin_calendar',
    ];
   
    $this->controls['event_limit'] = [
      'tab'     => 'content',
      'group'   => 'eventin_calendar',
      'label'   => esc_html__( 'Event Limit', 'bricks' ),
      'type'    => 'number',
      'min'     => 0,
      'inline'  => true,
      'default' => 20,
    ];
    $this->controls['show_child_event'] = [
      'tab'       => 'content',
      'label'     => esc_html__( 'Show Recurring Child Events', 'eventin-bricks-addon' ),
      'type'      => 'select',
      'options'   => [
        'no'      => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'     => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'    => true,
      'clearable' => true,
      'default'   => 'no',
      'group'     => 'eventin_calendar',
    ];
    $this->controls['show_parent_event'] = [
      'tab'       => 'content',
      'label'     => esc_html__( 'Show Recurring Parent Events', 'eventin-bricks-addon' ),
      'type'      => 'select',
      'options'   => [
        'no'      => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'     => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'    => true,
      'clearable' => true,
      'default'   => 'yes',
      'group'     => 'eventin_calendar',
    ];
  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'calendar-event' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[] = 'Etn-Event-Calendar';
    $calendar_event_style = $this->settings['calendar_event_style'];
    $calendar_display_style = $this->settings['calendar_display_style'];   
    $limit = $this->settings['event_limit'];
    $show_child_event = $this->settings['show_child_event'];
    $show_parent_event = $this->settings['show_parent_event'];
    $show_event_desc = $this->settings['show_event_desc'];
    $event_cats_list = isset($this->settings['select_cats']) ? ($this->settings['select_cats']) : '';

    // event cats
    if (is_array($event_cats_list)) {
      $event_cats = implode(", ", $event_cats_list);
    } else {
      $event_cats = (string)$event_cats_list;
    }
    
    if ( ! empty( $this->settings['type'] ) ) {
      $root_classes[] = "color-{$this->settings['type']}";
    }

    // Add 'class' attribute to element root tag
    $this->set_attribute( 'Etn_Event_Calendar', 'class', $root_classes );

    // Render element HTML
    // '_root' attribute is required since Bricks 1.4 (contains element ID, class, etc.)
    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
      echo do_shortcode("[events_calendar style ='$calendar_event_style' event_cat_ids ='$event_cats' calendar_show='$calendar_display_style' show_desc='$show_event_desc' limit = '$limit' show_child_event='$show_child_event' show_parent_event='$show_parent_event']");
    echo '</div>';
  }

  public function get_event_category(){
      return Helper::get_event_category();
  }

  public function get_event_tag(){
      return Helper::get_event_tag();
  }

}