<?php 
// element-test.php
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Event_Calendar_Pro extends \Bricks\Element {
    // Element properties
    public $category     = 'general';
    public $name         = 'event-calendar-pro';
    public $icon         = 'fa-regular fa-calendar';
    public $css_selector = '.prefix-test-wrapper';
    public $scripts      = ['prefixElementTest'];

    // Return localised element label
    public function get_label() {
        return esc_html__( 'Event Calender [Pro]', 'eventin-bricks-addon' );
    }

    // Set builder control groups
    public function set_control_groups() {
        $this->control_groups['eventin_event'] = [ // Unique group identifier (lowercase, no spaces)
            'title' => esc_html__( 'Eventin Event', 'eventin-bricks-addon' ),
            'tab'   => 'content',
        ];

        $this->control_groups['eventin_event_style'] = [
            'title' => esc_html__( 'Eventin Event', 'eventin-bricks-addon' ),
            'tab'   => 'style',
        ];
    }
 
    // Set builder controls
    public function set_controls() {

        $this->controls['select_cats'] = [
        'tab'      => 'content',
        'label'    => esc_html__( 'Select Category', 'eventin-bricks-addon' ),
        'type'     => 'select',
        'multiple' => true,
        'options'  => $this->get_event_category(),
        'group'    => 'eventin_event',
        ];

        
        $this->controls['slot_enable'] = [
            'tab'       => 'content',
            'label'     => esc_html__( 'All Day Slot Enable', 'eventin-bricks-addon' ),
            'type'      => 'select',
            'options'   => [
                'yes'   => esc_html__( 'Yes', 'eventin-bricks-addon' ),
                'no'    => esc_html__( 'No', 'eventin-bricks-addon' ),
            ],
            'inline'    => true,
            'clearable' => true,
            'default'   => 'yes',
            'group'     => 'eventin_event',
        ];

        $this->controls['display_calendar'] = [
            'tab'              => 'content',
            'label'            => esc_html__( 'Display Calendar', 'eventin-bricks-addon' ),
            'type'             => 'select',
            'options'          => [
                'dayGridMonth' => esc_html__( 'Monthly', 'eventin-bricks-addon' ),
                'timeGridWeek' => esc_html__( 'Weekly', 'eventin-bricks-addon' ),
                'timeGridDay'  => esc_html__( 'Daily', 'eventin-bricks-addon' ),
            ],
            'inline'           => true,
            'clearable'        => true,
            'default'          => 'timeGridWeek',
            'group'            => 'eventin_event',
        ];
        $this->controls['recurring_child_event'] = [
            'tab'       => 'content',
            'label'     => esc_html__( 'Show Recurring Child Events', 'eventin-bricks-addon' ),
            'type'      => 'select',
            'options'   => [
                'no'    => esc_html__( 'No', 'eventin-bricks-addon' ),
                'yes'   => esc_html__( 'Yes', 'eventin-bricks-addon' ),
            ],
            'inline'    => true,
            'clearable' => true,
            'default'   => 'no',
            'group'     => 'eventin_event',
        ];
        
        $this->controls['recurring_parent_event'] = [
            'tab'       => 'content',
            'label'     => esc_html__( 'Show Recurring Parent Events', 'eventin-bricks-addon' ),
            'type'      => 'select',
            'options'   => [
            'no'        => esc_html__( 'No', 'eventin-bricks-addon' ),
            'yes'       => esc_html__( 'Yes', 'eventin-bricks-addon' ),
            ],
            'inline'    => true,
            'clearable' => true,
            'default'   => 'yes',
            'group'     => 'eventin_event',
        ];

        $this->controls['select_option_bg_color'] = [
            'tab'              => 'style',
            'label'            => esc_html__( 'Select Option Background Color', 'eventin-bricks-addon' ),
            'type'             => 'color',
            'inline'           => true,
            'group'            => 'eventin_event_style',
            'css'              => [
                [
                    'property' => 'background-color',
                    'selector' => '.events_calendar_standard .cat-dropdown-list select',
                ]
            ]
        ];
    }

    public function enqueue_scripts() {
        wp_enqueue_script( 'prefix-test-script' );
    }

    // Render element HTML
    public function render() {
        // Set element attributes
        $root_classes[]         = 'prefix-test-wrapper';
        $recurring_child_event  = $this->settings['recurring_child_event'];
        $recurring_parent_event = $this->settings['recurring_parent_event'];
        $slot_enable            = $this->settings['slot_enable'];
        $display_calendar       = $this->settings['display_calendar'];
        $event_cats_list        = isset($this->settings['select_cats']) ? $this->settings['select_cats']: '';

        if (is_array($event_cats_list)) {
            $event_cats = implode(", ", $event_cats_list);
        } else {
            $event_cats = (string)$event_cats_list;
        }

        if ( ! empty( $this->settings['type'] ) ) {
            $root_classes[] = "color-{$this->settings['type']}";
        }

        $this->set_attribute( '_root', 'class', $root_classes );
        echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes

        echo do_shortcode("[etn_pro_calendar_standard event_cat_ids = '$event_cats' all_day_slot='$slot_enable' calendar_view='$display_calendar' show_child_event='$recurring_child_event' show_parent_event='$recurring_parent_event']");
        echo '</div>';
    }

    public function get_event_category(){
        return Helper::get_event_category();
    }

}