<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Event_Attendee_List extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'attendee-list'; // Make sure to prefix your elements
  public $icon         = 'ti-list'; // Themify icon font class
  public $css_selector = '.etn-attendee-list'; // Default CSS selector
  public $scripts      = ['attendee-list']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Attendee List (Pro)', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['eventin_attendee'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Attendee List', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content',
    ];
  }
 
  // Set builder controls
  public function set_controls() {

    $this->controls['event_list'] = [
      'tab'      => 'content',
      'label'    => esc_html__( 'Select Event', 'eventin-bricks-addon' ),
      'type'     => 'select',
      'multiple' => false,
      'options'  => $this->get_events(),
      'group'    => 'eventin_attendee',
    ];

    $this->controls['show_avater'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Show Avater', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'no'        => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'       => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'No', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'no',
      'group'       => 'eventin_attendee',
    ];
    $this->controls['show_email'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Show Email', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'no'        => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'       => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'No', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'no',
      'group'       => 'eventin_attendee',
    ];
  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'prefix-test-script' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[] = 'prefix-test-wrapper';
    
    $show_avater = $this->settings['show_avater'];
    $show_email = $this->settings['show_email'];

    $event_list = isset($this->settings['event_list']) ? ($this->settings['event_list']) : '';

    // event cats
    if (is_array($event_list)) {
      $event_lists = implode(", ", $event_list);
    } else {
      $event_lists = (string)$event_list;
    }

    
    if ( ! empty( $this->settings['type'] ) ) {
      $root_classes[] = "color-{$this->settings['type']}";
    }

    // Add 'class' attribute to element root tag
    $this->set_attribute( '_root', 'class', $root_classes );

    // Render element HTML
    // '_root' attribute is required since Bricks 1.4 (contains element ID, class, etc.)
    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
      echo do_shortcode("[etn_pro_attendee_list id ='$event_lists' show_avatar='$show_avater' show_email='$show_email']");
    echo '</div>';
  }

  public function get_events(){
      return Helper::get_events();
  }

}