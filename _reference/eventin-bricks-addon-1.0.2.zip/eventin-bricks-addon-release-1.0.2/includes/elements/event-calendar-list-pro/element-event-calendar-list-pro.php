<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Event_Calendar_List_Pro extends \Bricks\Element {
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'event-calendar-list-pro'; // Make sure to prefix your elements
  public $icon         = 'ti-calendar'; // Themify icon font class

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Event Calender List [Pro]', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['eventin_event'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Eventin Event', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {

    $this->controls['select_cats'] = [
      'tab'      => 'content',
      'label'    => esc_html__( 'Select Category', 'eventin-bricks-addon' ),
      'type'     => 'select',
      'multiple' => true,
      'options'  => $this->get_event_category(),
      'group'    => 'eventin_event',
    ];

    $this->controls['display_calendar'] = [
        'tab'         => 'content',
        'label'       => esc_html__( 'Calendar View', 'eventin-bricks-addon' ),
        'type'        => 'select',
        'options'     => [
          'listMonth' => esc_html__( 'Monthly', 'eventin-bricks-addon' ),
          'listWeek'  => esc_html__( 'Weekly', 'eventin-bricks-addon' ),
          'listDay'   => esc_html__( 'Daily', 'eventin-bricks-addon' ),
        ],
        'inline'      => true,
        'clearable'   => true,
        'default'     => 'listWeek',
        'group'       => 'eventin_event',
      ];
    
    $this->controls['recurring_parent_event'] = [
      'tab'       => 'content',
      'label'     => esc_html__( 'Show Recurring Parent Events', 'eventin-bricks-addon' ),
      'type'      => 'select',
      'options'   => [
        'no'      => esc_html__( 'No', 'eventin-bricks-addon' ),
        'yes'     => esc_html__( 'Yes', 'eventin-bricks-addon' ),
      ],
      'inline'    => true,
      'clearable' => true,
      'default'   => 'no',
      'group'     => 'eventin_event',
  ];

    $this->controls['recurring_child_event'] = [
        'tab'       => 'content',
        'label'     => esc_html__( 'Show Recurring Child Events', 'eventin-bricks-addon' ),
        'type'      => 'select',
        'options'   => [
            'no'    => esc_html__( 'No', 'eventin-bricks-addon' ),
            'yes'   => esc_html__( 'Yes', 'eventin-bricks-addon' ),
        ],
        'inline'    => true,
        'clearable' => true,
        'default'   => 'no',
        'group'     => 'eventin_event',
    ];
  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'prefix-test-script' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[]         = 'prefix-test-wrapper';
    $recurring_child_event  = $this->settings['recurring_child_event'];
    $recurring_parent_event = $this->settings['recurring_parent_event'];
    $display_calendar       = $this->settings['display_calendar'];
    $event_cats_list        = isset($this->settings['select_cats']) ? $this->settings['select_cats']: '';

    // event cats
    if (is_array($event_cats_list)) {
      $event_cats = implode(", ", $event_cats_list);
    } else {
      $event_cats = (string)$event_cats_list;
    }
    
    if ( ! empty( $this->settings['type'] ) ) {
      $root_classes[] = "color-{$this->settings['type']}";
    }
                                    
    // Add 'class' attribute to element root tag
    $this->set_attribute( '_root', 'class', $root_classes );

    // Render element HTML
    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
    echo do_shortcode("[etn_pro_calendar_list event_cat_ids = '$event_cats' calendar_view='$display_calendar' show_child_event='$recurring_child_event' show_parent_event='$recurring_parent_event']");
    echo '</div>';
  }

  public function get_event_category(){
      return Helper::get_event_category();
  }

}