<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Event_Speaker extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'event-speaker'; // Make sure to prefix your elements
  public $icon         = 'ti-user'; // Themify icon font class
  public $css_selector = '.eventin-event-speaker'; // Default CSS selector
  public $scripts      = ['eventin-event-speaker']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Event Speaker', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['eventin_speaker'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Eventin Speaker', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {
    $this->controls['speaker_style'] = [
      'tab' => 'content',
      'label' => esc_html__( 'Select Style', 'eventin-bricks-addon' ),
      'type' => 'select',
      'options' => [
        'speaker-1' => esc_html__( 'Style 1', 'eventin-bricks-addon' ),
        'speaker-2' => esc_html__( 'Style 2', 'eventin-bricks-addon' ),
      ],
      'inline' => true,
      'placeholder' => esc_html__( 'Select Style', 'eventin-bricks-addon' ),
      'clearable' => true,
      'default' => 'speaker-1',
      'group' => 'eventin_speaker',
    ];

    $this->controls['select_cats'] = [
      'tab' => 'content',
      'label' => esc_html__( 'Select Category', 'eventin-bricks-addon' ),
      'type' => 'select',
      'multiple'    => true,
      'options' => $this->get_speakers_category(),
      'group' => 'eventin_speaker',
    ];

    $this->controls['speaker_column'] = [
      'tab' => 'content',
      'label' => esc_html__( 'Column', 'eventin-bricks-addon' ),
      'type' => 'select',
      'options' => [
        '1' => esc_html__( 'Column 1', 'eventin-bricks-addon' ),
        '2' => esc_html__( 'Column 2', 'eventin-bricks-addon' ),
        '3' => esc_html__( 'Column 3', 'eventin-bricks-addon' ),
        '4' => esc_html__( 'Column 4', 'eventin-bricks-addon' ),
      ],
      'inline' => true,
      'placeholder' => esc_html__( 'Column 1', 'eventin-bricks-addon' ),
      'clearable' => true,
      'default' => '1',
      'group' => 'eventin_speaker',
    ];
   
    $this->controls['event_order'] = [
      'tab' => 'content',
      'label' => esc_html__( 'Select Order', 'eventin-bricks-addon' ),
      'type' => 'select',
      'options' => [
        'DESC' => esc_html__( 'DESC', 'eventin-bricks-addon' ),
        'ASC' => esc_html__( 'ASC', 'eventin-bricks-addon' )
      ],
      'inline' => true,
      'placeholder' => esc_html__( 'DESC', 'eventin-bricks-addon' ),
      'clearable' => true,
      'default' => 'DESC',
      'group' => 'eventin_speaker',
    ];
    
    $this->controls['event_orderby'] = [
      'tab' => 'content',
      'label' => esc_html__( 'Select Orderby', 'eventin-bricks-addon' ),
      'type' => 'select',
      'options' => [
        'title' => esc_html__( 'Title', 'eventin-bricks-addon' ),
        'ID' => esc_html__( 'ID', 'eventin-bricks-addon' ),
        'post_date' => esc_html__( 'Post Date', 'eventin-bricks-addon' ),
        'name' => esc_html__( 'Name', 'eventin-bricks-addon' )
      ],
      'inline' => true,
      'placeholder' => esc_html__( 'ID', 'eventin-bricks-addon' ),
      'clearable' => true,
      'default' => 'ID',
      'group' => 'eventin_speaker',
    ];

    $this->controls['event_limit'] = [
      'tab' => 'content',
      'group' => 'eventin_speaker',
      'label' => esc_html__( 'Speaker Limit', 'bricks' ),
      'type' => 'number',
      'min' => 0,
      'inline' => true,
      'default' => 20,
    ];
    
  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'event_speaker' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[]    = 'event_speaker';
    $speaker_style     = $this->settings['speaker_style'];
    $speaker_column    = $this->settings['speaker_column'];
    $order             = $this->settings['event_order'];
    $orderby           = $this->settings['event_orderby'];
    $limit             = $this->settings['event_limit'];
    $speakers_category = isset( $this->settings['select_cats']) ? ($this->settings['select_cats']): '';

    // speaker cats
    if (is_array($speakers_category)) {
      $speakers_category = implode(", ", $speakers_category);
    } else {
      $speakers_category = (string)$speakers_category;
    }
    
    if ( ! empty( $this->settings['type'] ) ) {
      $root_classes[] = "color-{$this->settings['type']}";
    }

    // Add 'class' attribute to element root tag
    $this->set_attribute( '_root', 'class', $root_classes );

    // Render element HTML
    // '_root' attribute is required since Bricks 1.4 (contains element ID, class, etc.)
    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
      echo do_shortcode("[speakers style ='$speaker_style' cat_id = '$speakers_category' etn_speaker_col ='$speaker_column' order='$order' orderby='$orderby' limit = '$limit']");
    echo '</div>';
  }

  public function get_speakers_category(){
      return Helper::get_speakers_category();
  }

}