<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Related_Event extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'related_event'; // Make sure to prefix your elements
  public $icon         = 'ti-layout-cta-btn-left'; // Themify icon font class
  public $css_selector = '.etn-related-event'; // Default CSS selector
  public $scripts      = ['related-event']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Related Event (Pro)', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['related_event'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Related Event', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {

    $this->controls['event_list'] = [
      'tab'      => 'content',
      'label'    => esc_html__( 'Select Event', 'eventin-bricks-addon' ),
      'type'     => 'select',
      'multiple' => false,
      'options'  => $this->get_events(),
      'group'    => 'related_event',
    ];
  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'etn-related-event' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[] = 'prefix-test-wrapper';
    $event_list     = isset($this->settings['event_list']) ? ($this->settings['event_list']): '';

    // event cats
    if (is_array($event_list)) {
      $event_lists = implode(", ", $event_list);
    } else {
      $event_lists = (string)$event_list;
    }
    
    if ( ! empty( $this->settings['type'] ) ) {
      $root_classes[] = "color-{$this->settings['type']}";
    }

    // Add 'class' attribute to element root tag
    $this->set_attribute( '_root', 'class', $root_classes );

    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
      echo do_shortcode("[etn_pro_related_events id = '$event_lists']");
    echo '</div>';
  }

  public function get_events(){
      return Helper::get_events();
  }

}