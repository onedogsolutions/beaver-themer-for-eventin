<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Event_Countdown_Pro extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'event-countdown-pro'; // Make sure to prefix your elements
  public $icon         = 'ti-power-off'; // Themify icon font class
  public $css_selector = '.event-countdown-pro'; // Default CSS selector
  public $scripts      = ['event-countdown-pro']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Eventin Event Countdown (Pro)', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['eventin_countdown_pro'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Eventin Event Countdown Pro', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {

    $this->controls['event_id'] = [
      'tab' => 'content',
      'label' => esc_html__( 'Select Event', 'eventin-bricks-addon' ),
      'type' => 'select',
      'multiple'    => false,
      'options' => $this->get_events(),
      'group' => 'eventin_countdown_pro',
    ];

  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'advance-search' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[] = 'eventin-search';

    $event_countdown = isset($this->settings['event_id']) ? ($this->settings['event_id']) : '';

    if (is_array($event_countdown)) {
      $event_countdown_item = implode(", ", $event_countdown);
    } else {
      $event_countdown_item = (string)$event_countdown;
    }
   

    // Render element HTML
    // '_root' attribute is required since Bricks 1.4 (contains element ID, class, etc.)
    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
      echo do_shortcode("[etn_pro_countdown event_id = '$event_countdown_item']");
    echo '</div>';
  }

  public function get_events(){
      return Helper::get_events();
  }

}