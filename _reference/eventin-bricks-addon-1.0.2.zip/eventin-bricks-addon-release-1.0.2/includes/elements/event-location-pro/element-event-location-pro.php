<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Eventin_Location_Pro extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'event-location-pro'; // Make sure to prefix your elements
  public $icon         = 'ti-location-pin'; // Themify icon font class
  public $css_selector = '.event-location-pro'; // Default CSS selector
  public $scripts      = ['event-location-pro']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Eventin Event Location (Pro)', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['eventin_location_pro'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Eventin Event Location Pro', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {

    $this->controls['style'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Select Style', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'style-1'   => esc_html__( 'Style 1', 'eventin-bricks-addon' ),
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'Select Style', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'style-1',
      'group'       => 'eventin_location_pro',
    ];

    $this->controls['location_limit'] = [
      'tab'     => 'content',
      'group'   => 'eventin_location_pro',
      'label'   => esc_html__( 'Event Limit', 'eventin-bricks-addon' ),
      'type'    => 'number',
      'min'     => 0,
      'inline'  => true,
      'default' => 4,
    ];

  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'advance-search' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[] = 'eventin-search';
    $limit          = $this->settings['location_limit'];
    $location_style = $this->settings['style'];

   
    // Render element HTML
    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
    echo do_shortcode("[etn_pro_event_location_list style ='$location_style' location_limit = '$limit']");
    echo '</div>';
  }

}