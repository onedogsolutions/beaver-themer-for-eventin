<?php 
// element-test.php
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Event_Speaker_Slider_Pro extends \Bricks\Element {
    // Element properties
    public $category     = 'general'; // Use predefined element category 'general'
    public $name         = 'event-speaker-slider-pro'; // Make sure to prefix your elements
    public $icon         = 'ti-layout-slider'; // Themify icon font class
    public $css_selector = '.prefix-test-wrapper'; // Default CSS selector
    public $scripts      = ['prefixElementTest']; // Script(s) run when element is rendered on frontend or updated in builder

    // Return localised element label
    public function get_label() {
        return esc_html__( 'Event Speaker Slider [Pro]', 'eventin-bricks-addon' );
    }

    // Set builder control groups
    public function set_control_groups() {
        $this->control_groups['eventin_event'] = [ // Unique group identifier (lowercase, no spaces)
            'title' => esc_html__( 'Eventin Event', 'eventin-bricks-addon' ), // Localized control group title
            'tab' => 'content', // Set to either "content" or "style"
        ];

        $this->control_groups['eventin_event_style'] = [ // Unique group identifier (lowercase, no spaces)
            'title' => esc_html__( 'Eventin Event', 'eventin-bricks-addon' ), // Localized control group title
            'tab' => 'style', // Set to either "content" or "style"
        ];
    }
 
    // Set builder controls
    public function set_controls() {

        $this->controls['style'] = [
            'tab'         => 'content',
            'label'       => esc_html__( 'Select Style', 'eventin-bricks-addon'),
            'type'        => 'select',
            'options'     => [
                'style-1' => esc_html__( 'Style One', 'eventin-bricks-addon' ),
                'style-2' => esc_html__( 'Style Two', 'eventin-bricks-addon' ),
                'style-3' => esc_html__( 'Style Three', 'eventin-bricks-addon' ),
                'style-4' => esc_html__( 'Style Four', 'eventin-bricks-addon' ),
                'style-5' => esc_html__( 'Style Five', 'eventin-bricks-addon' ),
            ],
            'group'       => 'eventin_event',
            'default'     => 'style-1',
        ];

        $this->controls['categories_id'] = [
            'tab'       => 'content',
            'label'     => esc_html__( 'Select Category', 'eventin-bricks-addon' ),
            'type'      => 'select',
            'options'   => $this->get_speakers_category(),
            'inline'    => true,
            'clearable' => true,
            'default'   => '3',
            'group'     => 'eventin_event',
            'multiple'  => true,
        ];

        $this->controls['auto_play'] = [
            'tab'       => 'content',
            'label'     => esc_html__( 'Autoplay', 'eventin-bricks-addon' ),
            'type'      => 'select',
            'options'   => [
                'yes'   => esc_html__( 'Yes', 'eventin-bricks-addon' ),
                'no'    => esc_html__( 'No', 'eventin-bricks-addon' ),
            ],
            'inline'    => true,
            'clearable' => true,
            'default'   => 'no',
            'group'     => 'eventin_event',
        ];

        $this->controls['orderby'] = [
            'tab'           => 'content',
            'label'         => esc_html__( 'Select Orderby', 'eventin-bricks-addon' ),
            'type'          => 'select',
            'options'       => [
                'title'     => esc_html__( 'Title', 'eventin-bricks-addon' ),
                'ID'        => esc_html__( 'ID', 'eventin-bricks-addon' ),
                'post_date' => esc_html__( 'Post Date', 'eventin-bricks-addon' ),
                'name'      => esc_html__( 'Name', 'eventin-bricks-addon' ),
            ],
            'inline'        => true,
            'placeholder'   => esc_html__( 'ID', 'eventin-bricks-addon' ),
            'clearable'     => true,
            'default'       => 'ID',
            'group'         => 'eventin_event',
        ];

        $this->controls['order'] = [
            'tab'         => 'content',
            'label'       => esc_html__( 'Select Order', 'eventin-bricks-addon' ),
            'type'        => 'select',
            'options'     => [
                'DESC'    => esc_html__( 'DESC', 'eventin-bricks-addon' ),
                'ASC'     => esc_html__( 'ASC', 'eventin-bricks-addon' )
            ],
            'inline'      => true,
            'placeholder' => esc_html__( 'DESC', 'eventin-bricks-addon' ),
            'clearable'   => true,
            'default'     => 'DESC',
            'group'       => 'eventin_event',
        ];

        $this->controls['show_designation'] = [
            'tab'       => 'content',
            'label'     => esc_html__( 'Show Designation', 'eventin-bricks-addon' ),
            'type'      => 'select',
            'options'   => [
                'yes'   => esc_html__( 'Yes', 'eventin-bricks-addon' ),
                'no'    => esc_html__( 'No', 'eventin-bricks-addon' ),
            ],
            'inline'    => true,
            'clearable' => true,
            'default'   => 'yes',
            'group'     => 'eventin_event',
        ];

        $this->controls['show_social'] = [
            'tab'       => 'content',
            'label'     => esc_html__( 'Show Social', 'eventin-bricks-addon' ),
            'type'      => 'select',
            'options'   => [
                'yes'   => esc_html__( 'Yes', 'eventin-bricks-addon' ),
                'no'    => esc_html__( 'No', 'eventin-bricks-addon' ),
            ],
            'inline'    => true,
            'clearable' => true,
            'default'   => 'no',
            'group'     => 'eventin_event',
        ];

        $this->controls['slider_nav_show'] = [
            'tab'       => 'content',
            'label'     => esc_html__( 'Slider Nav Show', 'eventin-bricks-addon' ),
            'type'      => 'select',
            'options'   => [
                'yes'   => esc_html__( 'Yes', 'eventin-bricks-addon' ),
                'no'    => esc_html__( 'No', 'eventin-bricks-addon' ),
            ],
            'inline'    => true,
            'clearable' => true,
            'default'   => 'no',
            'group'     => 'eventin_event',
        ];

        $this->controls['slider_dot_show'] = [
            'tab'       => 'content',
            'label'     => esc_html__( 'Slider Dot Show', 'eventin-bricks-addon' ),
            'type'      => 'select',
            'options'   => [
                'yes'   => esc_html__( 'Yes', 'eventin-bricks-addon' ),
                'no'    => esc_html__( 'No', 'eventin-bricks-addon' ),
            ],
            'inline'    => true,
            'clearable' => true,
            'default'   => 'no',
            'group'     => 'eventin_event',
        ];

        $this->controls['speaker_count'] = [
            'tab'     => 'content',
            'label'   => esc_html__( 'Speaker Count', 'eventin-bricks-addon' ),
            'type'    => 'number',
            'min'     => 0,
            'step'    => '1', // Default: 1
            'inline'  => true,
            'default' => 6,
            'group'   => 'eventin_event',
        ];

        $this->controls['slider_count'] = [
            'tab'     => 'content',
            'label'   => esc_html__( 'Slider Count', 'eventin-bricks-addon' ),
            'type'    => 'number',
            'min'     => 0,
            'step'    => '1', // Default: 1
            'inline'  => true,
            'default' => 3,
            'group'   => 'eventin_event',
        ];
        
    }

    // Enqueue element styles and scripts
    public function enqueue_scripts() {
        wp_enqueue_script( 'prefix-test-script' );
    }

    // Render element HTML
    public function render() {
        // Set element attributes
        $root_classes[]    = 'prefix-test-wrapper';
        $style             = $this->settings['style'];
        $auto_play         = $this->settings['auto_play'];
        $orderby           = $this->settings['orderby'];
        $order             = $this->settings['order'];
        $show_designation  = $this->settings['show_designation'];
        $show_social       = $this->settings['show_social'];
        $slider_nav_show   = $this->settings['slider_nav_show'];
        $slider_dot_show   = $this->settings['slider_dot_show'];
        $speaker_count     = $this->settings['speaker_count'];
        $slider_count      = $this->settings['slider_count'];
        $speaker_cats_list = isset($this->settings['categories_id']) ? ($this->settings['categories_id']): '';
        $speakers_category = isset($this->settings['categories_id']) ? ''                                : '';
        
        // Speaker cats
        if (is_array($speaker_cats_list)) {
            $speakers_category = implode(", ", $speaker_cats_list);
        } else {
            $speakers_category = (string)$speaker_cats_list;
        }
        
        if ( ! empty( $this->settings['type'] ) ) {
            $root_classes[] = "color-{$this->settings['type']}";
        }
        

        // Add 'class' attribute to element root tag
        $this->set_attribute( '_root', 'class', $root_classes );

        // Render element HTML
        // '_root' attribute is required since Bricks 1.4 (contains element ID, class, etc.)
        echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes

        echo do_shortcode("[etn_pro_speakers_sliders style ='$style' categories_id ='$speakers_category' auto_play='$auto_play' orderby='$orderby' order='$order' show_designation='$show_designation' show_social='$show_social' slider_nav_show='$slider_nav_show' slider_dot_show='$slider_dot_show' speaker_count ='$speaker_count' slider_count = '$slider_count']");
        echo '</div>';
    }

    protected function get_speakers_category()
    {
        return Helper::get_speakers_category();
    }

}