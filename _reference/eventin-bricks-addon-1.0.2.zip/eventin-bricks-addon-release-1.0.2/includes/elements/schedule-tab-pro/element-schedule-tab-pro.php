<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Schedule_Tab_Pro extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'schedule_tab'; // Make sure to prefix your elements
  public $icon         = 'ti-layout-tab'; // Themify icon font class
  public $css_selector = '.etn-schedule-tab'; // Default CSS selector
  public $scripts      = ['schedule-tab']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Schedule Tab (Pro)', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['schedule_tab'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Schedule Tab', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {

    $this->controls['schedule_order'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Select Order', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'DESC'      => esc_html__( 'DESC', 'eventin-bricks-addon' ),
        'ASC'       => esc_html__( 'ASC', 'eventin-bricks-addon' )
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'DESC', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'DESC',
      'group'       => 'schedule_tab',
    ];

    $this->controls['select_schedule'] = [
      'tab'      => 'content',
      'label'    => esc_html__( 'Select Schedule', 'eventin-bricks-addon' ),
      'type'     => 'select',
      'multiple' => true,
      'options'  => $this->get_schedules(),
      'group'    => 'schedule_tab',
    ];
  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'etn-related-event' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[]  = 'prefix-test-wrapper';
    $select_schedule = isset($this->settings['select_schedule']) ? ($this->settings['select_schedule']): '';
    $schedule_order  = $this->settings['schedule_order'];

    if (is_array($select_schedule)) {
      $select_schedule = implode(", ", $select_schedule);
    } else {
      $select_schedule = (string)$select_schedule;
    }
    
    
    if ( ! empty( $this->settings['type'] ) ) {
      $root_classes[] = "color-{$this->settings['type']}";
    }

    // Add 'class' attribute to element root tag
    $this->set_attribute( '_root', 'class', $root_classes );

    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
    echo do_shortcode("[etn_pro_schedules_tab order='$schedule_order' ids = '$select_schedule']");
    echo '</div>';
  }

  public function get_schedules(){
      return Helper::get_schedules();
  }

}