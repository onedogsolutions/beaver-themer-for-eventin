<?php 
use Etn\Utils\Helper;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Etn_Schedule_List_Pro extends \Bricks\Element {
  // Element properties
  public $category     = 'general'; // Use predefined element category 'general'
  public $name         = 'schedule_list'; // Make sure to prefix your elements
  public $icon         = 'ti-list'; // Themify icon font class
  public $css_selector = '.etn-schedule-list'; // Default CSS selector
  public $scripts      = ['schedule-list']; // Script(s) run when element is rendered on frontend or updated in builder

  // Return localised element label
  public function get_label() {
    return esc_html__( 'Schedule List (Pro)', 'eventin-bricks-addon' );
  }

  // Set builder control groups
  public function set_control_groups() {
    $this->control_groups['schedule_list'] = [ // Unique group identifier (lowercase, no spaces)
      'title' => esc_html__( 'Schedule List', 'eventin-bricks-addon' ), // Localized control group title
      'tab' => 'content', // Set to either "content" or "style"
    ];
  }
 
  // Set builder controls
  public function set_controls() {

    $this->controls['schedule_order'] = [
      'tab'         => 'content',
      'label'       => esc_html__( 'Select Order', 'eventin-bricks-addon' ),
      'type'        => 'select',
      'options'     => [
        'DESC'      => esc_html__( 'DESC', 'eventin-bricks-addon' ),
        'ASC'       => esc_html__( 'ASC', 'eventin-bricks-addon' )
      ],
      'inline'      => true,
      'placeholder' => esc_html__( 'DESC', 'eventin-bricks-addon' ),
      'clearable'   => true,
      'default'     => 'DESC',
      'group'       => 'schedule_list',
    ];

    $this->controls['select_schedule'] = [
      'tab'      => 'content',
      'label'    => esc_html__( 'Select Schedule', 'eventin-bricks-addon' ),
      'type'     => 'select',
      'multiple' => false,
      'options'  => $this->get_schedules(),
      'group'    => 'schedule_list',
    ];
  }

  // Enqueue element styles and scripts
  public function enqueue_scripts() {
    wp_enqueue_script( 'etn-related-event' );
  }

  // Render element HTML
  public function render() {
    // Set element attributes
    $root_classes[]  = 'prefix-test-wrapper';
    $select_schedule = $this->settings['select_schedule'];
    $schedule_order  = $this->settings['schedule_order'];
    
    if ( ! empty( $this->settings['type'] ) ) {
      $root_classes[] = "color-{$this->settings['type']}";
    }

    // Add 'class' attribute to element root tag
    $this->set_attribute( '_root', 'class', $root_classes );

    // Render element HTML
    // '_root' attribute is required since Bricks 1.4 (contains element ID, class, etc.)
    echo "<div {$this->render_attributes( '_root' )}>"; // Element root attributes
      echo do_shortcode("[etn_pro_schedules_list order='$schedule_order' ids = '$select_schedule']");
    echo '</div>';
  }

  public function get_schedules(){
      return Helper::get_schedules();
  }

}