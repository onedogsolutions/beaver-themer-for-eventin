<?php
defined( 'ABSPATH' ) || exit;

/**
 * event term select
 *
 * @since 1.0.0
 *
 * @return $all_terms
 * @return $term_includes
 */
