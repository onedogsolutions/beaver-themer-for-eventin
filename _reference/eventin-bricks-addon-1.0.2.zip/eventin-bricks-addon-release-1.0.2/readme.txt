===Eventin Bricks Addon===
Contributors: themewinter, ataurr, abrasel600
Tags: event, bricks addon, events
Requires at least: 5.2
Tested up to: 6.5.2
Stable tag: 1.0.2
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


Eventin - Bricks Builder Addons for Event Management, Event Calendar and so on...

== Changelog ==
= 1.0.2 ( October 17, 2024 )=
Fix: Event Tab Pro Filter Control Issue
Tweak: Event Ticket Width Issue 
Tweak: Event Classic Pro Width Issue 
Update: Remove Unused Control 
Compatible : Eventin V4

= 1.0.1 ( May 06, 2024 )=
Tweak: Plugin dependency updated

= 1.0.0 ( February 26, 2023 )=

* initial release


== Description ==

