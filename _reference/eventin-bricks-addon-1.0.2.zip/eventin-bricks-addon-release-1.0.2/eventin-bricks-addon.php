<?php

/**
 *  @package eventin-bricks-addon
 */
/**
 * Plugin Name:        Eventin Bricks Addon
 * Requires Plugins:   wp-event-solution
 * Plugin URI:         https://product.themewinter.com/eventin
 * Description:        Simple and Easy to use Event Management Solution With Bricks.
 * Version:            1.0.2
 * Author:             Themewinter
 * Author URI:         http://themewinter.com/
 * License:            GPL-2.0+
 * License URI:        http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:        eventin-bricks-addon
 * Domain Path:       /languages
 */
defined('ABSPATH') || exit;

require_once ABSPATH . 'wp-admin/includes/plugin.php';

final class Eventin_Bricks_Addon
{

    /**
     * Plugin Version
     *
     * @since 1.0.2
     *
     * @var string The plugin version.
     */
    static function version()
    {
        return '1.0.2';
    }

    /**
     * Instance of self
     *
     * @since 1.0.0
     *
     * @var Eventin_Bricks_Addon
     */
    private static $instance = null;

    /**
     * Initializes the Eventin_Bricks_Addon() class
     *
     * Checks for an existing Eventin_Bricks_Addon() instance
     * and if it doesn't find one, creates it.
     */
    public static function init()
    {

        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Instance of Eventin_Bricks_Addon
     */
    private function __construct()
    {

        // Check if Bricks Builder is installed.
        if ('bricks' !== wp_get_theme()->get('Template') || !is_plugin_active('wp-event-solution/eventin.php')) {
            if ('Bricks' !== wp_get_theme()->get('Name') || !is_plugin_active('wp-event-solution/eventin.php')) {
                add_action(
                    'admin_notices',
                    function () {
                        $message = sprintf(
                            /* translators: 1: Theme name 2: Eventin */
                            esc_html__('In order to use %1$s  you must have installed and activated %2$s &amp; %3$s', 'eventin-bricks-addon'),
                            '<strong>Eventin Bricks Addon</strong>',
                            '<strong>Bricks Builder</strong>',
                            '<strong>Eventin Plugin</strong>'
                        );
                        $html = sprintf('<div class="notice notice-warning">%s</div>', wpautop($message));
                        echo wp_kses_post($html);
                    }
                );
                return;
            }
        }


        // Load translation
        add_action('init', [$this, 'i18n']);

        add_action('wp_enqueue_scripts', [$this, 'enqueue_custom_styles']);

        // Instantiate Base Class after plugins loaded
        // add_action( 'bricks_extensions_init', [$this, 'initialize_module'] );
        $this->load_dependencies();

        add_action(
            'init',
            function () {
                $file_names = $this->etn_bricks_load_elements();

                foreach ($file_names as $file_name) {
                    $file = __DIR__ . "/includes/elements/$file_name/element-$file_name.php";
                    // Register all element in builder and frontend.
                    \Bricks\Elements::register_element($file);
                }
            },
            11
        );
    }
    /**
     * helper method load
     */
    public function load_dependencies()
    {
        require_once plugin_dir_path(__FILE__) . '/includes/helper.php';
    }
    /**
     * Custom Css file Load
     */
    public function enqueue_custom_styles()
    {
        wp_enqueue_style('bricks-custom', plugin_dir_url(__FILE__) . 'assets/custom-style.css', array(), '1.0.1', 'all');
    }

    /**
     * Load Textdomain
     *
     * Load plugin localization files.
     * Fired by `init` action hook.
     *
     */
    public function i18n()
    {
        load_plugin_textdomain('eventin-bricks-addon', false, dirname(self::plugins_basename()) . '/languages/');
    }


    /**
     * Plugin Url
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function plugin_url()
    {
        return trailingslashit(plugin_dir_url(self::plugin_file()));
    }

    /**
     * Plugin Directory Path
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function plugin_dir()
    {
        return trailingslashit(plugin_dir_path(self::plugin_file()));
    }

    /**
     * Plugins Basename
     *
     * @since 1.0.0

     */
    public static function plugins_basename()
    {
        return plugin_basename(self::plugin_file());
    }

    /**
     * Plugin File
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function plugin_file()
    {
        return __FILE__;
    }

    public function get_elements()
    {
        $elements     = array();
        $elements_dir = __DIR__ . '/includes/elements';
        $scan         = scandir($elements_dir);
        foreach ($scan as $result) {
            if ('.' === $result || '..' === $result) {
                continue;
            }
            if (is_dir($elements_dir . '/' . $result)) {
                $elements[] = $result;
            }
        }
        return $elements;
    }

    /**
     * Eventin Bricks Elements
     */
    public function etn_bricks_load_elements()
    {
        $file_names = $this->get_elements();
        return $file_names;
    }
}

/**
 * Load Eventin Bricks Addon when all plugins are loaded
 *
 * @return Eventin_Bricks_Addon
 */
function eventin_bricks_addon()
{
    return Eventin_Bricks_Addon::init();
}

// Let's Go...
eventin_bricks_addon();
