<?php

namespace Eventin_Oxygen_Addon;

defined('ABSPATH') || exit;

use Eventin_Oxygen_Addon\Autoloader;

/**
 * Eventin_Oxygen_addon autoloader.
 * Hangles dynamically loading classes only when needed.
 *
 * @since 1.0.0
 */

require_once plugin_dir_path(__FILE__) . '/autoloader.php';

class Bootstrap
{
    private static $instance;
    /**
     * Internal flag to prevent recursive the_content replacement.
     *
     * @var bool
     */
    private $is_replacing_content = false;
    /**
     * Register action
     */
    public function __construct()
    {
        // load autoload method
        Autoloader::run();
    }

    public function init()
    {

        // activation and deactivation hook
        register_activation_hook(__FILE__, [$this, 'active']);
        register_deactivation_hook(__FILE__, [$this, 'deactive']);

        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . '/wp-admin/includes/plugin.php';
        }

        if (!is_plugin_active('wp-event-solution/eventin.php')) {
            add_action('admin_notices', [$this, 'notice_eventin_not_active']);
            return;
        }

        if (!class_exists('OxyEl')) {
            //Required Oxygen Plugin
            add_action('admin_notices', [$this, 'notice_oxygen_not_active']);
            return;
        }

        //enqueue file
        \Eventin_Oxygen_Addon\Core\Enqueue\Enqueue::instance()->init();

        // load all elements (same timing as original plugin)
        add_action('init', [ $this, 'load_elements_files' ], 10);

        // Register +Add eventin section
        add_action('oxygen_add_plus_sections', array($this, 'register_add_plus_section'));

        // Register +Add eventin subsections
        // oxygen_add_plus_{$id}_section_content
        add_action('oxygen_add_plus_eventin_section_content', array($this, 'register_add_plus_subsections'));

        // Turn off Eventin's own single event template override so Oxygen templates can control header/footer for single "etn" posts
        add_action('init', array($this, 'disable_eventin_single_template_override'), 9999);
    }

    /**
     * Remove Eventin's own single event template overrides so Oxygen's templates
     * can handle header/footer for single "etn" posts (mirrors Tutor LMS addon approach).
     */
    public function disable_eventin_single_template_override() {
        if ( is_admin() ) {
            return;
        }

        global $wp_filter;

        if ( ! isset( $wp_filter['template_include'] ) || ! is_object( $wp_filter['template_include'] ) ) {
            return;
        }

        $hook = $wp_filter['template_include'];

        if ( empty( $hook->callbacks ) || ! is_array( $hook->callbacks ) ) {
            return;
        }

        foreach ( $hook->callbacks as $priority => $callbacks ) {
            foreach ( $callbacks as $id => $callback ) {
                if ( empty( $callback['function'] ) ) {
                    continue;
                }

                $fn = $callback['function'];

                if ( is_array( $fn ) && is_object( $fn[0] ) && is_string( $fn[1] ) ) {
                    $class  = get_class( $fn[0] );
                    $method = $fn[1];

                    if (
                        $method === 'event_single_page'
                        && (
                            $class === 'Eventin\\Event\\EventTemplate'
                            || $class === 'Etn\\Core\\Event\\Pages\\Event_single_post'
                        )
                    ) {
                        unset( $wp_filter['template_include']->callbacks[ $priority ][ $id ] );
                    }
                }
            }
        }
    }

    public function load_elements_files()
    {
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/oxy_eventin_el.php';

        /**
         * Single Event template (enables Oxygen header/footer for single etn post type)
         */
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/SingleEvent.php';

        /**
         * food Menu Elements
         */
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_list.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_tab.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_calendar.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_speaker.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_schedule_list.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_schedule_tab.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_advance_search.php';

        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_certificate_ticket_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_certificate_attendee_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_certificate_date_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_certificate_title_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_frontend_dashboard_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_location_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_recurring_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_calendar_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_calendar_list_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_speaker_classic_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_speaker_standard_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_organizer_list_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_speaker_slider_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_classic_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_standard_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_one_line_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_tab_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_slider_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_countdown_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_schedule_lists_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_ticket_form_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/related_event_widget_pro.php';
        include_once \Eventin_Oxygen_Addon::plugin_dir() . 'elements/event_attendee_list_pro.php';
    }

    // section add
    public function register_add_plus_section()
    {
        \CT_Toolbar::oxygen_add_plus_accordion_section("eventin", esc_html__("Eventin", 'eventin-oxygen-addon'));
    }

    // sub section add
    public function register_add_plus_subsections()
    {?>

		<h2>
            <?php esc_html_e("Single Template", 'eventin-oxygen-addon');?>
        </h2>
		<?php do_action("oxygen_add_plus_eventin_single_template");?>

		<h2>
            <?php esc_html_e("Eventin Free", 'eventin-oxygen-addon');?>
        </h2>
		<?php do_action("oxygen_add_plus_eventin_etn_free");?>

		<h2>
            <?php esc_html_e("Eventin Pro", 'eventin-oxygen-addon');?>
        </h2>
		<?php do_action("oxygen_add_plus_eventin_etn_pro");?>

	    <?php
}

    /**
     * do stuff on active
     *
     * @return void
     */
    public function active()
    {

    }

    /**
     * do stuff on deactive
     *
     * @return void
     */
    public function deactive()
    {
        flush_rewrite_rules();
    }

    /**
     * Singleton Instance
     *
     * @return void
     */
    public static function instance()
    {

        if (!self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function notice_eventin_not_active()
    {
        $message = sprintf(
            /* translators: 1: Theme name 2: Eventin */
            esc_html__('In order to use %1$s  you must have installed and activated %2$s ', 'eventin-oxygen-addon'),
            '<strong>Eventin Oxygen Addon</strong>',
            '<strong>Eventin & Oxygen Plugin</strong>'
        );
        $html = sprintf('<div class="notice notice-warning">%s</div>', wpautop($message));
        echo wp_kses_post($html);
    }

    public function notice_oxygen_not_active()
    {
        $message = sprintf(
            /* translators: 1: Theme name 2: Eventin */
            esc_html__('In order to use %1$s  you must have installed and activated %2$s Plugin.', 'eventin-oxygen-addon'),
            '<strong>Eventin Oxygen Addon</strong>',
            '<strong>Oxygen Builder</strong>'
        );
        $html = sprintf('<div class="notice notice-warning">%s</div>', wpautop($message));
        echo wp_kses_post($html);
    }

}