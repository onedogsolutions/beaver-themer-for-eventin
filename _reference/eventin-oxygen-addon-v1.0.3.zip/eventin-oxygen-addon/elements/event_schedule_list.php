<?php

namespace Oxygen\EventinElements;

class Event_Schedule_List extends \Oxy_Eventin_El
{

    private $query_params = array(
        'order' => '',
        'ids' => '',
    );

    public function name()
    {
        return 'Event Schedule List';
    }

    public function eventin_button_place()
    {
        return "etn_free";
    }

    public function icon()
    {
        return '';
    }

    public function render($options, $defaults, $content)
    {

        $shortcode_props = shortcode_atts($this->query_params, $options);

        $atts_string = '';

        foreach ($shortcode_props as $name => $value) {
            if ($value) {
                $atts_string .= ' ' . $name . '=' . $value;
            }
        }

        $shortcode = '[schedules_list ' . $atts_string . ']';
        echo do_shortcode($shortcode);
    }

    public function controls()
    {
        /* Event Query Section */
        $event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Schedule ID', 'eventin-oxygen-addon'),
                "slug" => 'ids',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Select Order', 'eventin-oxygen-addon'),
                "slug" => 'order',
                'default' => 'DESC',
            )
        )->setValue(array('DESC', 'ASC'));

        /* Style section */
        $selector = '.schedule-list-wrapper';
        $style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

        /* Title Style */
        $title_style = $style_sections->addControlSection("title_style", esc_html__("Title Style", 'eventin-oxygen-addon'), " ", $this);
        $title_selector = $selector . "  .schedule-listing.multi-schedule-list .schedule-slot-info h3.schedule-slot-title";
        $title_selector_color = $selector . " .schedule-listing.multi-schedule-list .schedule-slot-info h3.schedule-slot-title";
        $title_style->addStyleControls(
            array(

                array(
                    "selector" => $title_selector_color,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        /* Description Style */
        $desc_style = $style_sections->addControlSection("desc_style", esc_html__("Description Style", 'eventin-oxygen-addon'), " ", $this);
        $desc_selector = $selector . " .schedule-listing.multi-schedule-list .schedule-slot-info p";
        $desc_style->addStyleControls(
            array(

                array(
                    "selector" => $desc_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        /* time_slot Style */
        $time_slot_style = $style_sections->addControlSection("time_slot_style", esc_html__("Time Slot Style", 'eventin-oxygen-addon'), " ", $this);
        $time_slot_bg_selector = $selector . " .schedule-listing.multi-schedule-list .schedule-slot-time";
        $time_slot_selector = $selector . " .schedule-listing.multi-schedule-list .schedule-slot-time span";
        $time_slot_style->addStyleControls(
            array(

                array(
                    "selector" => $time_slot_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $time_slot_bg_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $time_slot_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $time_slot_selector,
                    "property" => 'font-family',
                ),

            )
        );

    }
}

new Event_Schedule_List();
