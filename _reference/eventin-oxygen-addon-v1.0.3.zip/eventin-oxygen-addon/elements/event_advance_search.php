<?php

namespace Oxygen\EventinElements;

class Event_Advance_Search extends \Oxy_Eventin_El {

    private $query_params = array(
		'order'         => '',
    );

	function name() {
		return 'Event Advance Search';
	}

	public function eventin_button_place() {
		return "etn_free";
	}

	function icon() {
		return '';
	}

	function render($options, $defaults, $content) {
		 	
        $shortcode_props = shortcode_atts($this->query_params, $options);

		$atts_string = '';

		foreach ($shortcode_props as $name => $value) {
			if ($value) {
				$atts_string .= ' '.$name.'='.$value;
			}
		}

        $shortcode = '[event_search_filter '.$atts_string.']';
		echo do_shortcode($shortcode);
	}


	
	public function controls() {

		/* Style section */
		$selector = ' .search-button-wrapper';
		$style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

		/* Title Style */
		$button_style = $style_sections->addControlSection("title_style", esc_html__("Button Style", 'eventin-oxygen-addon'), " ", $this);
		$button_selector = $selector." button.etn-btn.etn-btn-primary";
		$button_selector_color = $selector." button.etn-btn.etn-btn-primary";
		$button_selector_bg_color = $selector." button.etn-btn.etn-btn-primary";
		$button_style->addStyleControls(
			array(
			 
				array(
					"selector" => $button_selector_color,
					"property" => 'color',
				),
				array(
					"selector" => $button_selector,
					"property" => 'font-size',
				),
				array(
					"selector" => $button_selector,
					"property" => 'font-family',
				),
				array(
					"selector" => $button_selector,
					"property" => 'line-height',
				),
				array(
					"selector" => $button_selector,
					"property" => 'text-transform',
				),
				array(
					"selector" => $button_selector_bg_color ,
					"property" => 'background-color',
				)
			)
		);

		
	}
}

new Event_Advance_Search();