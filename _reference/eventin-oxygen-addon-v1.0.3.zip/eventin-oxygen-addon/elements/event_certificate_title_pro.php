<?php

namespace Oxygen\EventinElements;

class Event_Certificate_Title_Pro extends \Oxy_Eventin_El {

    private $query_params = array(
    );

	function name() {
		return 'Event Title Certificate (Pro)';
	}

	public function eventin_button_place() {
		return "etn_pro";
	}

	function icon() {
		return '';
	}

	function render($options, $defaults, $content) {
		 	
        $shortcode_props = shortcode_atts($this->query_params, $options);

		$atts_string = '';

		foreach ($shortcode_props as $name => $value) {
			if ($value) {
				$atts_string .= ' '.$name.'='.$value;
			}
		}

        $shortcode = '[etn_pro_event_title '.$atts_string.']';
		echo do_shortcode($shortcode);
	}


}

new Event_Certificate_Title_Pro();