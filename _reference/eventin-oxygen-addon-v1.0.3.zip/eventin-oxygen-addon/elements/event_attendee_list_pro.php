<?php

namespace Oxygen\EventinElements;

class Eventin_Event_Attendee_List_Pro extends \Oxy_Eventin_El
{

    private $query_params = array(
        'id' => '',
        'show_avatar' => '',
        'show_email' => '',
    );

    public function name()
    {
        return 'Eventin Attendee List(Pro)';
    }

    public function eventin_button_place()
    {
        return "etn_pro";
    }

    public function icon()
    {
        return '';
    }

    public function render($options, $defaults, $content)
    {

        $shortcode_props = shortcode_atts($this->query_params, $options);

        $atts_string = '';

        foreach ($shortcode_props as $name => $value) {
            if ($value) {
                $atts_string .= ' ' . $name . '=' . $value;
            }
        }

        $shortcode = '[etn_pro_attendee_list' . $atts_string . ']';
        echo do_shortcode($shortcode);
    }

    public function controls()
    {
        /* Course Query Section */
        $event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event ID', 'eventin-oxygen-addon'),
                "slug" => 'id',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Avatar', 'eventin-oxygen-addon'),
                "slug" => 'show_avatar',
                "default" => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Email', 'eventin-oxygen-addon'),
                "slug" => 'show_email',
                "default" => 'no',
            )
        )->setValue(array('yes', 'no'));
    }
}

new Eventin_Event_Attendee_List_Pro();
