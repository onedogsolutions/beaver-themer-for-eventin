<?php

namespace Oxygen\EventinElements;

class Eventin_Event_Speaker_Standard_Pro extends \Oxy_Eventin_El
{

    private $query_params = array(
        'speakers_category' => '',
        'speaker_col' => '',
        'orderby' => '',
        'order' => '',
        'show_designation' => '',
        'show_social' => '',
        'speaker_count' => '',
    );

    public function name()
    {
        return 'Eventin Speaker Standard(Pro)';
    }

    public function eventin_button_place()
    {
        return "etn_pro";
    }

    public function icon()
    {
        return '';
    }

    public function render($options, $defaults, $content)
    {

        $shortcode_props = shortcode_atts($this->query_params, $options);

        $atts_string = '';

        foreach ($shortcode_props as $name => $value) {
            if ($value) {
                $atts_string .= ' ' . $name . '=' . $value;
            }
        }

        $shortcode = '[etn_pro_speakers_standard' . $atts_string . ']';
        echo do_shortcode($shortcode);
    }

    public function controls()
    {
        /* Course Query Section */
        $event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Speaker Category IDs', 'eventin-oxygen-addon'),
                "slug" => 'speakers_category',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Speaker Column', 'eventin-oxygen-addon'),
                "slug" => 'speaker_col',
                'default' => '3',
            )
        )->setValue(array('1', '2', '3', '4'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Select Order By', 'eventin-oxygen-addon'),
                "slug" => 'orderby',
                'default' => 'ID',
            )
        )->setValue(array('ID', 'title', 'post_date', 'name'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Select Order', 'eventin-oxygen-addon'),
                "slug" => 'order',
                'default' => 'DESC',
            )
        )->setValue(array('DESC', 'ASC'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Designation', 'eventin-oxygen-addon'),
                "slug" => 'show_designation',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Social', 'eventin-oxygen-addon'),
                "slug" => 'show_social',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Speaker Counter', 'eventin-oxygen-addon'),
                "slug" => 'speaker_count',
            )
        );

        /* Style section */
        $selector = '.etn-single-speaker-item';
        $style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

        $title_style = $style_sections->addControlSection("title_style", esc_html__("Title Style", 'eventin-oxygen-addon'), " ", $this);
        $title_selector = $selector . " .etn-speaker-content .etn-speaker-title a";
        $title_style->addStyleControls(
            array(
                array(
                    "selector" => $title_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        $title_style = $style_sections->addControlSection("designation_style", esc_html__("Designation Style", 'eventin-oxygen-addon'), " ", $this);
        $title_selector = $selector . " p";
        $title_style->addStyleControls(
            array(
                array(
                    "selector" => $title_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        $social_style = $style_sections->addControlSection("social_style", esc_html__("Social Style", 'eventin-oxygen-addon'), " ", $this);
        $social_selector = $selector . " .etn-speaker-thumb .etn-speakers-social a";
        $social_style->addStyleControls(
            array(
                array(
                    "selector" => $social_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $social_selector,
                    "property" => 'font-size',
                ),
            )
        );

        $social_hover_style = $style_sections->addControlSection("social_hover_style", esc_html__("Social Hover Style", 'eventin-oxygen-addon'), " ", $this);
        $social_selector = $selector . " .etn-speaker-thumb .etn-speakers-social a:hover";
        $social_hover_style->addStyleControls(
            array(
                array(
                    "selector" => $social_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $social_selector,
                    "property" => 'font-size',
                ),
            )
        );
    }
}

new Eventin_Event_Speaker_Standard_Pro();
