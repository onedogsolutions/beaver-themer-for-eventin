<?php

namespace Oxygen\EventinElements;

class Eventin_Event_Calendar_List_Pro extends \Oxy_Eventin_El {

    private $query_params = array(
		'event_cat_ids'     => '',
		'calendar_view'     => '',
		'show_child_event'  => '',
		'show_parent_event' => '',
    );

	function name() {
		return 'Eventin Calendar List(Pro)';
	}

	public function eventin_button_place() {
		return "etn_pro";
	}

	function icon() {
		return '';
	}

	function render($options, $defaults, $content) {
		 	
        $shortcode_props = shortcode_atts($this->query_params, $options);

		$atts_string = '';

		foreach ($shortcode_props as $name => $value) {
			if ($value) {
				$atts_string .= ' '.$name.'='.$value;
			}
		}

        $shortcode = '[etn_pro_calendar_list'.$atts_string.']';
		echo do_shortcode($shortcode);
	}
	
	public function controls() {
		/* Course Query Section */
		$event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);

		$event_query->addOptionControl(
			array(
				"type" => 'textfield',
				"name" => esc_html__('Event Category IDs', 'eventin-oxygen-addon'),
				"slug" => 'event_cat_ids',
			)
		);

		$event_query->addOptionControl(
			array(
				"type" => 'buttons-list',
				"name" => esc_html__('Display Calendar View', 'eventin-oxygen-addon'),
				"slug" => 'calendar_view',
				'default' => 'listWeek',
			)
		)->setValue(array('listMonth', 'listWeek', 'listDay'));

		$event_query->addOptionControl(
			array(
				"type" => 'buttons-list',
				"name" => esc_html__('Show Child Event', 'eventin-oxygen-addon'),
				"slug" => 'show_child_event',
				'default' => 'yes',
			)
		)->setValue(array('yes', 'no'));

		$event_query->addOptionControl(
			array(
				"type" => 'buttons-list',
				"name" => esc_html__('Show Child Event', 'eventin-oxygen-addon'),
				"slug" => 'show_parent_event',
				'default' => 'yes',
			)
		)->setValue(array('yes', 'no'));	
	}
}

new Eventin_Event_Calendar_List_Pro();