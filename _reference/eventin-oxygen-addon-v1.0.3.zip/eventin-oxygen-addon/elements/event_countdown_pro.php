<?php

namespace Oxygen\EventinElements;

class Eventin_Countdown_Pro extends \Oxy_Eventin_El {

    private $query_params = array(
		'event_id'     => ''
    );

	function name() {
		return 'Eventin Event Countdown(Pro)';
	}

	public function eventin_button_place() {
		return "etn_pro";
	}

	function icon() {
		return '';
	}

	function render($options, $defaults, $content) {
		 	
        $shortcode_props = shortcode_atts($this->query_params, $options);

		$atts_string = '';

		foreach ($shortcode_props as $name => $value) {
			if ($value) {
				$atts_string .= ' '.$name.'='.$value;
			}
		}

        $shortcode = '[etn_pro_countdown'.$atts_string.']';
		echo do_shortcode($shortcode);
	}



	
	public function controls() {
		/* Course Query Section */
		$event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);

		$event_query->addOptionControl(
			array(
				"type" => 'textfield',
				"name" => esc_html__('Event ID', 'eventin-oxygen-addon'),
				"slug" => 'event_id',
			)
		);	
	}
}

new Eventin_Countdown_Pro();