<?php

namespace Oxygen\EventinElements;

class Eventin_Event_Speaker_Slider_Pro extends \Oxy_Eventin_El
{

    private $query_params = array(
        'style' => '',
        'categories_id' => '',
        'auto_play' => '',
        'orderby' => '',
        'order' => '',
        'show_designation' => '',
        'show_social' => '',
        'slider_nav_show' => '',
        'slider_dot_show' => '',
        'speaker_count' => '',
        'slider_count' => '',
    );

    public function name()
    {
        return 'Eventin Speaker Slider(Pro)';
    }

    public function eventin_button_place()
    {
        return "etn_pro";
    }

    public function icon()
    {
        return '';
    }

    public function render($options, $defaults, $content)
    {

        $shortcode_props = shortcode_atts($this->query_params, $options);

        $atts_string = '';

        foreach ($shortcode_props as $name => $value) {
            if ($value) {
                $atts_string .= ' ' . $name . '=' . $value;
            }
        }

        $shortcode = '[etn_pro_speakers_sliders' . $atts_string . ']';
        echo do_shortcode($shortcode);
    }

    public function controls()
    {
        /* Course Query Section */
        $event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Select Style', 'eventin-oxygen-addon'),
                "slug" => 'style',
                'default' => 'style-1',
            )
        )->setValue(array('style-1', 'style-2', 'style-3', 'style-4', 'style-5'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Speaker Category IDs', 'eventin-oxygen-addon'),
                "slug" => 'categories_id',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Autoplay', 'eventin-oxygen-addon'),
                "slug" => 'auto_play',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Select Order By', 'eventin-oxygen-addon'),
                "slug" => 'orderby',
                'default' => 'ID',
            )
        )->setValue(array('ID', 'title', 'post_date', 'name'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Select Order', 'eventin-oxygen-addon'),
                "slug" => 'order',
                'default' => 'DESC',
            )
        )->setValue(array('DESC', 'ASC'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Designation', 'eventin-oxygen-addon'),
                "slug" => 'show_designation',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Social', 'eventin-oxygen-addon'),
                "slug" => 'show_social',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Nav', 'eventin-oxygen-addon'),
                "slug" => 'slider_nav_show',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Dot', 'eventin-oxygen-addon'),
                "slug" => 'slider_dot_show',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Speaker Counter', 'eventin-oxygen-addon'),
                "slug" => 'speaker_count',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Slider Counter', 'eventin-oxygen-addon'),
                "slug" => 'slider_count',
            )
        );

        /* Style section */
        $selector = '.etn-single-speaker-item';
        $style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

        $title_style = $style_sections->addControlSection("title_style", esc_html__("Title Style", 'eventin-oxygen-addon'), " ", $this);
        $title_selector = $selector . " .etn-speaker-content .etn-speaker-title a";
        $title_style->addStyleControls(
            array(
                array(
                    "selector" => $title_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        $title_style = $style_sections->addControlSection("designation_style", esc_html__("Designation Style", 'eventin-oxygen-addon'), " ", $this);
        $title_selector = $selector . " p";
        $title_style->addStyleControls(
            array(
                array(
                    "selector" => $title_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
            )
        );

        $slider_selector = '.etn-speaker-slider';
        $slider_nav_style = $style_sections->addControlSection("slider_nav_style", esc_html__("Slider Nav Style", 'eventin-oxygen-addon'), " ", $this);
        $nav_selector = $slider_selector . " .swiper-button-next, .swiper-button-prev";
        $slider_nav_style->addStyleControls(
            array(
                array(
                    "selector" => $nav_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $nav_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $nav_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
            )
        );

        $slider_nav_hover_style = $style_sections->addControlSection("slider_nav_hover_style", esc_html__("Slider Nav Hover Style", 'eventin-oxygen-addon'), " ", $this);
        $nav_selector = $slider_selector . " .swiper-button-next:hover, .swiper-button-prev:hover";
        $slider_nav_hover_style->addStyleControls(
            array(
                array(
                    "selector" => $nav_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $nav_selector,
                    "property" => 'background-color',
                ),
            )
        );

        $slider_dot_style = $style_sections->addControlSection("slider_dot_style", esc_html__("Slider Dot Style", 'eventin-oxygen-addon'), " ", $this);
        $dot_selector = $slider_selector . " .swiper-pagination";
        $slider_dot_style->addStyleControls(
            array(
                array(
                    "selector" => $dot_selector,
                    "property" => 'padding-top',
                ),
                array(
                    "selector" => $dot_selector,
                    "property" => 'margin-bottom',
                ),
            )
        );
    }
}

new Eventin_Event_Speaker_Slider_Pro();
