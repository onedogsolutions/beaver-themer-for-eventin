<?php

namespace Eventin_Oxygen_Addon\Elements;

defined( 'ABSPATH' ) || exit;

class SingleEvent extends \Oxy_Eventin_El {

	function name() {

		return esc_html__( 'Eventin Template', 'eventin-oxygen-addon' );
	}

	/**
	 * Element icon (optional). Leave empty to use default.
	 */
	function icon() {
		return \Eventin_Oxygen_Addon::assets_url() . 'eventin-template-icon.svg';
	}

	/**
	 * Render Eventin single event body only (no header/footer).
	 * Uses shared SingleEventBody so output matches the_content filter (Inner Content).
	 */
	function render( $options, $defaults, $content ) {
		global $post;

		// Detect Oxygen builder render, following the PostX pattern.
		$is_oxy_builder = isset( $_GET['action'] ) && strpos( sanitize_key( $_GET['action'] ), 'oxy_render_oxy' ) !== false;

		// In the Oxygen builder (when not actually editing a real single etn event),
		// show a visual placeholder so users can see where the Eventin template will appear.
		if ( $is_oxy_builder && ( ! $post || $post->post_type !== 'etn' ) ) {
			echo '<div class="etn-oxygen-single-event-wrap" data-etn-oxygen="single-event-wrapper">';
			echo '<div class="etn-oxygen-single-event-placeholder" style="border:1px dashed #999;padding:8px 10px;margin-bottom:10px;color:#555;background:#fff1f1;">Eventin Oxygen: Single Event template output will appear here on single event pages.</div>';
			echo '</div>';
			return;
		}

		// Front-end (and builder when actually previewing a single etn):
		// render the real Eventin single event body (no header/footer).
		\Eventin_Oxygen_Addon\Core\SingleEventBody::render();
	}

	/**
	 * Place this element under "Single Template" in Oxygen + Add > Eventin.
	 */
	public function eventin_button_place() {
		return 'single_template';
	}

	/**
	 * Optional: basic controls for wrapper styling.
	 */
	function controls() {
		$selector = '.etn-oxygen-single-event-wrap';
		$this->addControlSection(
			'etn_single_wrapper',
			__( 'Single Event Wrapper', 'eventin-oxygen-addon' ),
			'',
			$this
		)->addStyleControls(
			array(
				array(
					'name'     => __( 'Max Width', 'eventin-oxygen-addon' ),
					'selector' => $selector,
					'property' => 'max-width',
				),
				array(
					'name'     => __( 'Margin', 'eventin-oxygen-addon' ),
					'selector' => $selector,
					'property' => 'margin',
				),
			)
		);
	}
}

new SingleEvent();
