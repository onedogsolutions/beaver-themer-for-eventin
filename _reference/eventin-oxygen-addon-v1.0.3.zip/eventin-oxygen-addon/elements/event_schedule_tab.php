<?php

namespace Oxygen\EventinElements;

class Event_Schedule_Tab extends \Oxy_Eventin_El {

    private $query_params = array(
		'order'         => '',
		'ids'          => '',
    );

	function name() {
		return 'Event Schedule Tab';
	}

	public function eventin_button_place() {
		return "etn_free";
	}

	function icon() {
		return '';
	}

	function render($options, $defaults, $content) {
		 	
        $shortcode_props = shortcode_atts($this->query_params, $options);

		$atts_string = '';

		foreach ($shortcode_props as $name => $value) {
			if ($value) {
				$atts_string .= ' '.$name.'='.$value;
			}
		}

        $shortcode = '[schedules '.$atts_string.']';
		echo do_shortcode($shortcode);
	}


	
	public function controls() {
		/* Event Query Section */
		$event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);
		
		$event_query->addOptionControl(
			array(
				"type" => 'dropdown',
				"name" => esc_html__('Select Order', 'eventin-oxygen-addon'),
				"slug" => 'order',
				'default' => '',
			)
		)->setValue(array('DESC', 'ASC'));

		$event_query->addOptionControl(
			array(
				"type" => 'textfield',
				"name" => esc_html__('Schedule IDs', 'eventin-oxygen-addon'),
				"slug" => 'ids',
			)
		);

		/* Style section */
		$selector = '.schedule-tab-wrapper';
		$style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

		/* Title Style */
		$title_style = $style_sections->addControlSection("title_style", esc_html__("Title Style", 'eventin-oxygen-addon'), " ", $this);
		$title_selector = $selector." .etn-nav li a span.etn-date";
		$title_selector_color = $selector." .etn-nav li a span.etn-date";
		$title_style->addStyleControls(
			array(
			 
				array(
					"selector" => $title_selector_color,
					"property" => 'color',
				),
				array(
					"selector" => $title_selector,
					"property" => 'font-size',
				),
				array(
					"selector" => $title_selector,
					"property" => 'font-family',
				),
				array(
					"selector" => $title_selector,
					"property" => 'line-height',
				),
				array(
					"selector" => $title_selector,
					"property" => 'text-transform',
				)
			)
		);

	}
}

new Event_Schedule_Tab();