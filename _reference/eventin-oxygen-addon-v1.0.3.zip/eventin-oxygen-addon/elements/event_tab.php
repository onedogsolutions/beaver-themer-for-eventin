<?php

namespace Oxygen\EventinElements;

class Event_Tab extends \Oxy_Eventin_El
{

    private $query_params = array(
        'style' => ' ',
        'event_cat_ids' => '',
        'event_tag_ids' => '',
        'order' => '',
        'orderby' => '',
        'filter_with_status' => '',
        'etn_event_col' => '',
        'limit' => '',
        'show_end_date' => '',
        'show_child_event' => '',
        'show_parent_event' => '',
        'show_event_location' => '',
        'etn_desc_show' => '',
    );

    public function name()
    {
        return 'Event Tab';
    }

    public function eventin_button_place()
    {
        return "etn_free";
    }

    public function icon()
    {
        return '';
    }

    public function render($options, $defaults, $content)
    {

        $shortcode_props = shortcode_atts($this->query_params, $options);

        $atts_string = '';

        foreach ($shortcode_props as $name => $value) {
            if ($value) {
                $atts_string .= ' ' . $name . '=' . $value;
            }
        }

        $shortcode = '[events_tab ' . $atts_string . ']';
        echo do_shortcode($shortcode);
    }

    public function controls()
    {
        /* Event Query Section */
        $event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);
        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Style ', 'eventin-oxygen-addon'),
                "slug" => 'style',
                'default' => 'event-1',
            )
        )->setValue(array('event-1', 'event-2'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Category IDs', 'eventin-oxygen-addon'),
                "slug" => 'event_cat_ids',
            )
        );
        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Tags IDs', 'eventin-oxygen-addon'),
                "slug" => 'event_tag_ids',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Count', 'eventin-oxygen-addon'),
                "slug" => 'limit',
                "default" => "6",
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Limit', 'eventin-oxygen-addon'),
                "slug" => 'order',
                "default" => "6",
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Description', 'eventin-oxygen-addon'),
                "slug" => 'etn_desc_show',
                'default' => 'yes',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Description Limit', 'eventin-oxygen-addon'),
                "slug" => 'desc_limit',
                "default" => "20",
                "condition" => 'etn_show_desc=yes',
            )
        );
        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Limit', 'eventin-oxygen-addon'),
                "slug" => 'limit',
                "default" => '',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Description', 'eventin-oxygen-addon'),
                "slug" => 'etn_desc_show',
                'default' => 'yes',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Description Limit', 'eventin-oxygen-addon'),
                "slug" => 'desc_limit',
                "default" => "20",
                "condition" => 'etn_show_desc=yes',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Event Column', 'eventin-oxygen-addon'),
                "slug" => 'etn_event_col',
                'default' => '3',
            )
        )->setValue(array('1', '2', '3', '4'));

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Event status filter By', 'eventin-oxygen-addon'),
                "slug" => 'filter_with_status',
                'default' => 'all',
            )
        )->setValue(array('all', 'upcoming', 'expire'));

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Order Event By', 'eventin-oxygen-addon'),
                "slug" => 'orderby',
                'default' => '',
                "condition" => 'style=event-1',
            )
        )->setValue(array('ID', 'title', 'post_date', 'etn_start_date', 'etn_end_date'));

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Event Column', 'eventin-oxygen-addon'),
                "slug" => 'etn_event_col',
                'default' => '4',
            )
        )->setValue(array('3', '4', '6'));

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Event status filter By', 'eventin-oxygen-addon'),
                "slug" => 'filter_with_status',
                'default' => '',
            )
        )->setValue(array('', 'upcoming', 'expire'));

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Order Event By', 'eventin-oxygen-addon'),
                "slug" => 'orderby',
                'default' => '',
                "condition" => 'style=event-1',
            )
        )->setValue(array('ID', 'title', 'post_date', 'etn_start_date', 'etn_end_date'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Order', 'eventin-oxygen-addon'),
                "slug" => 'order',
                'default' => 'DESC',
            )
        )->setValue(array('DESC', 'ASC'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Event Location', 'eventin-oxygen-addon'),
                "slug" => 'show_event_location',
                'default' => 'yes',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show End Date', 'eventin-oxygen-addon'),
                "slug" => 'show_end_date',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));
        /* Location Style */
        /* Style section */
        $selector = '.etn-speaker-wrapper';
        $style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

        $location_style = $style_sections->addControlSection("location_style", esc_html__("Location Style", 'eventin-oxygen-addon'), " ", $this);
        $location_selector = $selector . "  .etn-event-item .etn-event-location";
        $location_style->addStyleControls(
            array(

                array(
                    "selector" => $location_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $location_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $location_selector,
                    "property" => 'font-family',
                ),

            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Recurring Parent Events', 'eventin-oxygen-addon'),
                "slug" => 'show_parent_event',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Recurring Child Event', 'eventin-oxygen-addon'),
                "slug" => 'show_child_event',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        /* Style section */
        $selector = '.etn-event-wrapper';
        $style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

        /* Title Style */
        $title_style = $style_sections->addControlSection("title_style", esc_html__("Title Style", 'eventin-oxygen-addon'), " ", $this);
        $title_selector = $selector . " .etn-event-item .etn-title";
        $title_selector_color = $selector . " .etn-event-item .etn-title a";
        $title_style->addStyleControls(
            array(

                array(
                    "selector" => $title_selector_color,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        /* Description Style */
        $desc_style = $style_sections->addControlSection("desc_style", esc_html__("Description Style", 'eventin-oxygen-addon'), " ", $this);
        $desc_selector = $selector . " .etn-event-item .etn-event-content p";
        $desc_style->addStyleControls(
            array(

                array(
                    "selector" => $desc_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        /* Location Style */
        $location_style = $style_sections->addControlSection("location_style", esc_html__("Location Style", 'eventin-oxygen-addon'), " ", $this);
        $location_selector = $selector . "  .etn-event-item .etn-event-location";
        $location_style->addStyleControls(
            array(

                array(
                    "selector" => $location_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $location_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $location_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $location_selector,
                    "property" => 'font-family',
                ),

            )
        );

        /* item status Style */
        $category_style = $style_sections->addControlSection("category_style", esc_html__("Category Style", 'eventin-oxygen-addon'), " ", $this);
        $category_selector = $selector . "  .etn-event-item .etn-event-category span";
        $category_style->addStyleControls(
            array(

                array(
                    "selector" => $category_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $category_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $category_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $category_selector,
                    "property" => 'font-family',
                ),

            )
        );

        /* Thumb Style */
        $thumb_style = $style_sections->addControlSection("thumb_style", esc_html__("Thumbnail Style", 'eventin-oxygen-addon'), " ", $this);
        $thumb_selector = $selector . " .etn-event-item .etn-event-thumb img";
        $thumb_style->addStyleControls(
            array(

                array(
                    "selector" => $thumb_selector,
                    "property" => 'border-radius',
                ),
            )
        );

        /* Button Style */
        $btn_style = $style_sections->addControlSection("btn_style", esc_html__("Button Style", 'eventin-oxygen-addon'), " ", $this);
        $btn_selector = $selector . " .etn-event-item .etn-event-footer .etn-atend-btn .etn-btn-border";
        $btn_style->addStyleControls(
            array(

                array(
                    "selector" => $btn_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $btn_selector,
                    "property" => 'background-color',
                ),

                array(
                    "selector" => $btn_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $btn_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $btn_selector,
                    "property" => 'border-color',
                ),
                array(
                    "selector" => $btn_selector,
                    "property" => 'border-width',
                ),
            )
        );

        /* Advance Button Style */
        $adv_style = $style_sections->addControlSection("advance_style", esc_html__("Advance Style", 'eventin-oxygen-addon'), " ", $this);
        $adv_selector = $selector . " .etn-event-item";
        $adv_style->addStyleControls(
            array(

                array(
                    "selector" => $adv_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'color',
                ),

                array(
                    "selector" => $adv_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'border-color',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'border-width',
                ),
            )
        );
    }
}

new Event_Tab();
