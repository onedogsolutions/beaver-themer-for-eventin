<?php

namespace Oxygen\EventinElements;

class Event_Location_pro extends \Oxy_Eventin_El {

    private $query_params = array(
		'style'    				 => ' ',
		'limit'       			 => '',
    );

	function name() {
		return 'Event Location (Pro)';
	}

	public function eventin_button_place() {
		return "etn_pro";
	}

	function icon() {
		return '';
	}

	function render($options, $defaults, $content) {
		 	
        $shortcode_props = shortcode_atts($this->query_params, $options);

		$atts_string = '';

		foreach ($shortcode_props as $name => $value) {
			if ($value) {
				$atts_string .= ' '.$name.'='.$value;
			}
		}

        $shortcode = '[etn_pro_event_location_list '.$atts_string.']';
		echo do_shortcode($shortcode);
	}


	
	public function controls() {
		/* Event Query Section */
		$event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);
		$event_query->addOptionControl(
			array(
				"type" => 'dropdown',
				"name" => esc_html__('Style ', 'eventin-oxygen-addon'),
				"slug" => 'style',
				'default' => 'style-1',
			)
		)->setValue(array('style-1'));

		$event_query->addOptionControl(
			array(
				"type" => 'textfield',
				"name" => esc_html__('Event limit', 'eventin-oxygen-addon'),
				"slug" => 'limit',
				'default' => 'no',
			)
		)->setValue(array('yes', 'no'));
	}
}

new Event_Location_pro();