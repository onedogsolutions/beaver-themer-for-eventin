<?php

namespace Oxygen\EventinElements;

class Eventin_Event_Standard_Pro extends \Oxy_Eventin_El
{

    private $query_params = array(
        'event_cat_ids' => '',
        'event_tag_ids' => '',
        'orderby' => '',
        'order' => '',
        'filter_with_status' => '',
        'event_col' => '',
        'show_desc' => '',
        'desc_limit' => '',
        'show_attendee_count' => '',
        'show_btn' => '',
        'show_thumb' => '',
        'show_category' => '',
        'event_count' => '',
        'show_end_date' => '',
        'show_child_event' => '',
        'show_parent_event' => '',
        'show_event_location' => '',
    );

    public function name()
    {
        return 'Eventin Event Standard(Pro)';
    }

    public function eventin_button_place()
    {
        return "etn_pro";
    }

    public function icon()
    {
        return '';
    }

    public function render($options, $defaults, $content)
    {

        $shortcode_props = shortcode_atts($this->query_params, $options);

        $atts_string = '';

        foreach ($shortcode_props as $name => $value) {
            if ($value) {
                $atts_string .= ' ' . $name . '=' . $value;
            }
        }

        $shortcode = '[etn_pro_events_standard' . $atts_string . ']';
        echo do_shortcode($shortcode);
    }

    public function controls()
    {
        /* Course Query Section */
        $event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Category IDs', 'eventin-oxygen-addon'),
                "slug" => 'event_cat_ids',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Tag IDs', 'eventin-oxygen-addon'),
                "slug" => 'event_tag_ids',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Select Order By', 'eventin-oxygen-addon'),
                "slug" => 'orderby',
                'default' => 'ID',
            )
        )->setValue(array('ID', 'title', 'post_date', 'name', 'etn_start_date', 'etn_end_date'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Select Order', 'eventin-oxygen-addon'),
                "slug" => 'order',
                'default' => 'DESC',
            )
        )->setValue(array('DESC', 'ASC'));

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Event status filter By', 'eventin-oxygen-addon'),
                "slug" => 'filter_with_status',
                'default' => 'All',
            )
        )->setValue(array('All', 'upcoming', 'expire'));

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Event Column', 'eventin-oxygen-addon'),
                "slug" => 'event_col',
                'default' => '4',
            )
        )->setValue(array('1', '2', '3', '4'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Description', 'eventin-oxygen-addon'),
                "slug" => 'show_desc',
                'default' => 'yes',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Description Limit', 'eventin-oxygen-addon'),
                "slug" => 'desc_limit',
                "condition" => 'show_desc=yes',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Attendee Count', 'eventin-oxygen-addon'),
                "slug" => 'show_attendee_count',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Attend Button', 'eventin-oxygen-addon'),
                "slug" => 'show_btn',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Thumbnail', 'eventin-oxygen-addon'),
                "slug" => 'show_thumb',
                'default' => 'yes',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Category', 'eventin-oxygen-addon'),
                "slug" => 'show_category',
                'default' => 'yes',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Limit', 'eventin-oxygen-addon'),
                "slug" => 'event_count',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show End Date', 'eventin-oxygen-addon'),
                "slug" => 'show_end_date',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Recurring Child Event', 'eventin-oxygen-addon'),
                "slug" => 'show_child_event',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Recurring Parent Event', 'eventin-oxygen-addon'),
                "slug" => 'show_parent_event',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Event Location', 'eventin-oxygen-addon'),
                "slug" => 'show_event_location',
                'default' => 'yes',
            )
        )->setValue(array('yes', 'no'));

        /* Style section */
        $selector = '.etn-event-item';
        $style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

        $title_style = $style_sections->addControlSection("title_style", esc_html__("Title Style", 'eventin-oxygen-addon'), " ", $this);
        $title_selector = $selector . " .etn-title a";
        $title_style->addStyleControls(
            array(
                array(
                    "selector" => $title_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        $description_style = $style_sections->addControlSection("description_style", esc_html__("Description Style", 'eventin-oxygen-addon'), " ", $this);
        $description_selector = $selector . " .etn-event-content .etn-title-info p";
        $description_style->addStyleControls(
            array(
                array(
                    "selector" => $description_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $description_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $description_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $description_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $description_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        $category_style = $style_sections->addControlSection("category_selector", esc_html__("Category Style", 'eventin-oxygen-addon'), " ", $this);
        $category_selector = $selector . " .etn-event-category span";
        $category_style->addStyleControls(
            array(
                array(
                    "selector" => $category_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $category_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $category_selector,
                    "property" => 'font-size',
                ),
            )
        );

        /* Thumb Style */
        $thumb_style = $style_sections->addControlSection("thumb_style", esc_html__("Thumbnail Style", 'eventin-oxygen-addon'), " ", $this);
        $thumb_selector = $selector . " .etn-event-thumb img";
        $thumb_style->addStyleControls(
            array(

                array(
                    "selector" => $thumb_selector,
                    "property" => 'border-radius',
                ),
            )
        );

        $button_style = $style_sections->addControlSection("btn_selector", esc_html__("Button Style", 'eventin-oxygen-addon'), " ", $this);
        $button_selector = $selector . " .etn-atend-btn a";
        $button_style->addStyleControls(
            array(
                array(
                    "selector" => $button_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $button_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $button_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $button_selector,
                    "property" => 'border-color',
                ),
                array(
                    "selector" => $button_selector,
                    "property" => 'border-width',
                ),
            )
        );

        $button_hover_style = $style_sections->addControlSection("btn_hover_selector", esc_html__("Button Hover Style", 'eventin-oxygen-addon'), " ", $this);
        $button_hover_selector = $selector . " .etn-atend-btn a:hover";
        $button_hover_style->addStyleControls(
            array(
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'border-color',
                ),
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'border-width',
                ),
            )
        );

        /* Advance Button Style */
        $event_wrapper = '.etn-event-wrapper';
        $adv_style = $style_sections->addControlSection("advance_style", esc_html__("Advance Style", 'eventin-oxygen-addon'), " ", $this);
        $adv_selector = $event_wrapper . " .etn-event-item";
        $adv_style->addStyleControls(
            array(
                array(
                    "selector" => $adv_selector,
                    "property" => 'background-color',
                ),
            )
        );
    }
}

new Eventin_Event_Standard_Pro();
