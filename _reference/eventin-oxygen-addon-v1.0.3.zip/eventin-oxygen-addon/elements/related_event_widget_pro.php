<?php

namespace Oxygen\EventinElements;

class Eventin_Event_Related_Widget_Pro extends \Oxy_Eventin_El
{

    private $query_params = array(
        'id' => '',
    );

    public function name()
    {
        return 'Related Event Widget(Pro)';
    }

    public function eventin_button_place()
    {
        return "etn_pro";
    }

    public function icon()
    {
        return '';
    }

    public function render($options, $defaults, $content)
    {

        $shortcode_props = shortcode_atts($this->query_params, $options);

        $atts_string = '';

        foreach ($shortcode_props as $name => $value) {
            if ($value) {
                $atts_string .= ' ' . $name . '=' . $value;
            }
        }

        $shortcode = '[etn_pro_related_events' . $atts_string . ']';
        echo do_shortcode($shortcode);
    }

    public function controls()
    {
        /* Course Query Section */
        $event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event ID', 'eventin-oxygen-addon'),
                "slug" => 'id',
            )
        );

        /* Style section */
        $selector = '.etn-event-item';
        $style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

        $title_style = $style_sections->addControlSection("title_style", esc_html__("Title Style", 'eventin-oxygen-addon'), " ", $this);
        $title_selector = $selector . " .etn-title a";
        $title_style->addStyleControls(
            array(
                array(
                    "selector" => $title_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        $title_hover_style = $style_sections->addControlSection("title_hover_style", esc_html__("Title Hover Style", 'eventin-oxygen-addon'), " ", $this);
        $title_hover_selector = $selector . " .etn-title a:hover";
        $title_hover_style->addStyleControls(
            array(
                array(
                    "selector" => $title_hover_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_hover_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_hover_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_hover_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        $category_style = $style_sections->addControlSection("category_selector", esc_html__("Category Style", 'eventin-oxygen-addon'), " ", $this);
        $category_selector = $selector . " .etn-event-category span";
        $category_style->addStyleControls(
            array(
                array(
                    "selector" => $category_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $category_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $category_selector,
                    "property" => 'font-size',
                ),
            )
        );

        $button_style = $style_sections->addControlSection("btn_selector", esc_html__("Button Style", 'eventin-oxygen-addon'), " ", $this);
        $button_selector = $selector . " .etn-atend-btn a";
        $button_style->addStyleControls(
            array(
                array(
                    "selector" => $button_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $button_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $button_selector,
                    "property" => 'font-size',
                ),
            )
        );

        $button_hover_style = $style_sections->addControlSection("btn_hover_selector", esc_html__("Button Hover Style", 'eventin-oxygen-addon'), " ", $this);
        $button_hover_selector = $selector . " .etn-atend-btn a:hover";
        $button_hover_style->addStyleControls(
            array(
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'font-size',
                ),
            )
        );
    }
}

new Eventin_Event_Related_Widget_Pro();
