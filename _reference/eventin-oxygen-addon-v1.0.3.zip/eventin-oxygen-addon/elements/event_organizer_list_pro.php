<?php

namespace Oxygen\EventinElements;

class Eventin_Event_Organizer_List_Pro extends \Oxy_Eventin_El {

    private $query_params = array(
		'etn_speaker_col' => '',
		'cat_id'          => '',
		'orderby'         => '',
		'order'           => '',
		'limit'           => '',
    );

	function name() {
		return 'Eventin Organizer List(Pro)';
	}

	public function eventin_button_place() {
		return "etn_pro";
	}

	function icon() {
		return '';
	}

	function render($options, $defaults, $content) {
		 	
        $shortcode_props = shortcode_atts($this->query_params, $options);

		$atts_string = '';

		foreach ($shortcode_props as $name => $value) {
			if ($value) {
				$atts_string .= ' '.$name.'='.$value;
			}
		}

        $shortcode = '[etn_pro_organizers'.$atts_string.']';
		echo do_shortcode($shortcode);
	}
	
	public function controls() {
		/* Course Query Section */
		$event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);

		$event_query->addOptionControl(
			array(
				"type" => 'textfield',
				"name" => esc_html__('Select Category IDs', 'eventin-oxygen-addon'),
				"slug" => 'cat_id',
			)
		);

		$event_query->addOptionControl(
			array(
				"type" => 'dropdown',
				"name" => esc_html__('Speaker Column', 'eventin-oxygen-addon'),
				"slug" => 'etn_speaker_col',
				'default' => '3',
			)
		)->setValue(array('1', '2', '3', '4'));

		$event_query->addOptionControl(
			array(
				"type" => 'buttons-list',
				"name" => esc_html__('Select Order By', 'eventin-oxygen-addon'),
				"slug" => 'orderby',
				'default' => 'ID',
			)
		)->setValue(array('ID', 'title', 'post_date', 'name'));

		$event_query->addOptionControl(
			array(
				"type" => 'buttons-list',
				"name" => esc_html__('Select Order', 'eventin-oxygen-addon'),
				"slug" => 'order',
				'default' => 'DESC',
			)
		)->setValue(array('DESC', 'ASC'));

		$event_query->addOptionControl(
			array(
				"type" => 'textfield',
				"name" => esc_html__('Post Limit', 'eventin-oxygen-addon'),
				"slug" => 'limit',
			)
		);
	}
}

new Eventin_Event_Organizer_List_Pro();