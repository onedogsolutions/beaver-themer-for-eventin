<?php

namespace Oxygen\EventinElements;

class Eventin_Event_One_line_Pro extends \Oxy_Eventin_El
{

    private $query_params = array(
        'event_cat_ids' => '',
        'event_tag_ids' => '',
        'orderby' => '',
        'order' => '',
        'filter_with_status' => '',
        'show_btn' => '',
        'show_thumb' => '',
        'show_category' => '',
        'event_count' => '',
        'show_end_date' => '',
        'show_child_event' => '',
        'show_parent_event' => '',
        'show_event_location' => '',
    );

    public function name()
    {
        return 'Eventin Event One Line(Pro)';
    }

    public function eventin_button_place()
    {
        return "etn_pro";
    }

    public function icon()
    {
        return '';
    }

    public function render($options, $defaults, $content)
    {

        $shortcode_props = shortcode_atts($this->query_params, $options);

        $atts_string = '';

        foreach ($shortcode_props as $name => $value) {
            if ($value) {
                $atts_string .= ' ' . $name . '=' . $value;
            }
        }

        $shortcode = '[etn_pro_events_one_line' . $atts_string . ']';
        echo do_shortcode($shortcode);
    }

    public function controls()
    {
        /* Course Query Section */
        $event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Category IDs', 'eventin-oxygen-addon'),
                "slug" => 'event_cat_ids',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Tag IDs', 'eventin-oxygen-addon'),
                "slug" => 'event_tag_ids',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Select Order By', 'eventin-oxygen-addon'),
                "slug" => 'orderby',
                'default' => 'ID',
            )
        )->setValue(array('ID', 'title', 'post_date', 'name', 'etn_start_date', 'etn_end_date'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Select Order', 'eventin-oxygen-addon'),
                "slug" => 'order',
                'default' => 'DESC',
            )
        )->setValue(array('DESC', 'ASC'));

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Event status filter By', 'eventin-oxygen-addon'),
                "slug" => 'filter_with_status',
                'default' => 'All',
            )
        )->setValue(array('All', 'upcoming', 'expire'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Attend Button', 'eventin-oxygen-addon'),
                "slug" => 'show_btn',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Thumbnail', 'eventin-oxygen-addon'),
                "slug" => 'show_thumb',
                'default' => 'yes',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Category', 'eventin-oxygen-addon'),
                "slug" => 'show_category',
                'default' => 'yes',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Event Limit', 'eventin-oxygen-addon'),
                "slug" => 'event_count',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show End Date', 'eventin-oxygen-addon'),
                "slug" => 'show_end_date',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Recurring Child Event', 'eventin-oxygen-addon'),
                "slug" => 'show_child_event',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Recurring Parent Event', 'eventin-oxygen-addon'),
                "slug" => 'show_parent_event',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        $event_query->addOptionControl(
            array(
                "type" => 'buttons-list',
                "name" => esc_html__('Show Event Location', 'eventin-oxygen-addon'),
                "slug" => 'show_event_location',
                'default' => 'no',
            )
        )->setValue(array('yes', 'no'));

        /* Style section */
        $selector = '.calendar-event-content';
        $style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

        $title_style = $style_sections->addControlSection("title_style", esc_html__("Title Style", 'eventin-oxygen-addon'), " ", $this);
        $title_selector = $selector . " .etn-title a";
        $title_style->addStyleControls(
            array(
                array(
                    "selector" => $title_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        $title_hover_style = $style_sections->addControlSection("title_hover_style", esc_html__("Title Hover Style", 'eventin-oxygen-addon'), " ", $this);
        $title_hover_selector = $selector . " .etn-title a:hover";
        $title_hover_style->addStyleControls(
            array(
                array(
                    "selector" => $title_hover_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_hover_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_hover_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_hover_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        $category_style = $style_sections->addControlSection("category_selector", esc_html__("Category Style", 'eventin-oxygen-addon'), " ", $this);
        $category_selector = $selector . " .calendar-event-category-wrap span";
        $category_style->addStyleControls(
            array(
                array(
                    "selector" => $category_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $category_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $category_selector,
                    "property" => 'font-size',
                ),
            )
        );

        $btn_selector = '.event-calendar-action';
        $button_style = $style_sections->addControlSection("btn_selector", esc_html__("Button Style", 'eventin-oxygen-addon'), " ", $this);
        $button_selector = $btn_selector . " .etn-btn";
        $button_style->addStyleControls(
            array(
                array(
                    "selector" => $button_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $button_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $button_selector,
                    "property" => 'font-size',
                ),
            )
        );

        $btn_selector = '.event-calendar-action';
        $button_hover_style = $style_sections->addControlSection("btn_hover_selector", esc_html__("Button Hover Style", 'eventin-oxygen-addon'), " ", $this);
        $button_hover_selector = $btn_selector . " .etn-btn:hover";
        $button_hover_style->addStyleControls(
            array(
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $button_hover_selector,
                    "property" => 'font-size',
                ),
            )
        );

        /* Advance Button Style */
        $adv_wrapper_selector = '.events_calendar_list';
        $adv_style = $style_sections->addControlSection("advance_style", esc_html__("Advance Style", 'eventin-oxygen-addon'), " ", $this);
        $adv_selector = $adv_wrapper_selector . " .calendar-event-details";
        $adv_style->addStyleControls(
            array(
                array(
                    "selector" => $adv_selector,
                    "property" => 'background-color',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'padding-top',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'padding-bottom',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'padding-left',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'padding-right',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'margin-bottom',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'border-color',
                ),
                array(
                    "selector" => $adv_selector,
                    "property" => 'border-width',
                ),
            )
        );
    }
}

new Eventin_Event_One_line_Pro();
