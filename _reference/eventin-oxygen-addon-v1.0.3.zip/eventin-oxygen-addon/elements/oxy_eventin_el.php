<?php

class Oxy_Eventin_El extends OxyEl {

	protected $params;
	function init() {

		$this->El->useAJAXControls();
		//$this->setAssetsPath( OXY_WOO_ASSETS_PATH );
	}
	function render($options, $defaults, $content) {
		if (method_exists($this, 'eventinTemplate')) {
			call_user_func($this->eventinTemplate());
		}
	}

	function class_names() {
		return array('oxy-eventin-element');
	}

	function controls() {

		//Les.Son.Compo.Nents
	}

	public function button_place() {
		$btn_place = $this->eventin_button_place();

		if ($btn_place){
			return "eventin::".$btn_place;
		}
		return "";
	}

}
