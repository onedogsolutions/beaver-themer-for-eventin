<?php

namespace Oxygen\EventinElements;

class Event_Speaker extends \Oxy_Eventin_El
{

    private $query_params = array(
        'style' => '',
        'cat_id' => '',
        'etn_speaker_col' => '',
        'order' => '',
        'orderby' => '',
        'limit' => '',
    );

    public function name()
    {
        return 'Event Speaker';
    }

    public function eventin_button_place()
    {
        return "etn_free";
    }

    public function icon()
    {
        return '';
    }

    public function render($options, $defaults, $content)
    {

        $shortcode_props = shortcode_atts($this->query_params, $options);

        $atts_string = '';

        foreach ($shortcode_props as $name => $value) {
            if ($value) {
                $atts_string .= ' ' . $name . '=' . $value;
            }
        }

        $shortcode = '[speakers ' . $atts_string . ']';
        echo do_shortcode($shortcode);
    }

    public function controls()
    {
        /* Event Query Section */
        $event_query = $this->addControlSection("event_query", esc_html__('Event Query', 'eventin-oxygen-addon'), "", $this);
        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Style ', 'eventin-oxygen-addon'),
                "slug" => 'style',
                'default' => 'speaker-1',
            )
        )->setValue(array('speaker-1', 'speaker-2'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Speaker Category IDs', 'eventin-oxygen-addon'),
                "slug" => 'cat_id',
            )
        );

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Event Column', 'eventin-oxygen-addon'),
                "slug" => 'etn_speaker_col',
                'default' => '4',
            )
        )->setValue(array('1', '3', '4', '6'));

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Select Order', 'eventin-oxygen-addon'),
                "slug" => 'order',
                'default' => 'DESC',
            )
        )->setValue(array('DESC', 'ASC'));

        $event_query->addOptionControl(
            array(
                "type" => 'dropdown',
                "name" => esc_html__('Speaker Orderby', 'eventin-oxygen-addon'),
                "slug" => 'orderby',
                'default' => 'ID',
            )
        )->setValue(array('ID', 'title', 'post_date', 'name'));

        $event_query->addOptionControl(
            array(
                "type" => 'textfield',
                "name" => esc_html__('Speaker Limit', 'eventin-oxygen-addon'),
                "slug" => 'limit',
            )
        );

        /* Style section */
        $selector = '.etn-speaker-wrapper';
        $style_sections = $this->addControlSection("style_sections", esc_html__("Style Sections", 'eventin-oxygen-addon'), " ", $this);

        /* Title Style */
        $title_style = $style_sections->addControlSection("title_style", esc_html__("Title Style", 'eventin-oxygen-addon'), " ", $this);
        $title_selector = $selector . " .etn-speaker-item .etn-speaker-content .etn-title a";
        $title_selector_color = $selector . " .etn-speaker-item .etn-speaker-content .etn-title a";
        $title_style->addStyleControls(
            array(

                array(
                    "selector" => $title_selector_color,
                    "property" => 'color',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $title_selector,
                    "property" => 'text-transform',
                ),
            )
        );

        /* Description Style */
        $desc_style = $style_sections->addControlSection("desc_style", esc_html__("Description Style", 'eventin-oxygen-addon'), " ", $this);
        $desc_selector = $selector . " .etn-speaker-item .etn-speaker-content p";
        $desc_style->addStyleControls(
            array(

                array(
                    "selector" => $desc_selector,
                    "property" => 'color',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'font-size',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'line-height',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'font-family',
                ),
                array(
                    "selector" => $desc_selector,
                    "property" => 'text-transform',
                ),
            )
        );
    }
}

new Event_Speaker();
