===Eventin Restaurant Addon for Oxygen Builder===
Requires at least: 5.2
Tested up to: 6.9.1
Stable tag: 1.0.2
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


Eventin - Oxygen Builder Addons for Event Management, Event Calendar and so on...

= 1.0.2 ( March 4, 2026 )
New     : Eventin Template support added

= 1.0.1 ( May 11, 2024 )
Tweak   : Plugin dependency updated

= 1.0.0 ( May 16, 2023 )
Initial Release
