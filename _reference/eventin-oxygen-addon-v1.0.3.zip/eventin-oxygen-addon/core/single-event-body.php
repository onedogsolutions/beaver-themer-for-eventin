<?php
/**
 * Renders Eventin single event body only (no header/footer).
 * Used by Single Event element and the_content filter for Oxygen Inner Content.
 *
 * @package Eventin_Oxygen_Addon
 */

namespace Eventin_Oxygen_Addon\Core;

defined( 'ABSPATH' ) || exit;

class SingleEventBody {

	public static function render() {
		global $post;

		if ( ! $post || $post->post_type !== 'etn' || ! is_singular( 'etn' ) ) {
			return;
		}

		$event = new \Etn\Core\Event\Event_Model( $post->ID );
		$use_block_template = ( $event->event_layout && 'etn-template' === get_post_type( $event->event_layout ) );

		echo '<div class="etn-oxygen-single-event-wrap" data-etn-oxygen="single-event-wrapper">';

		// Builder-only visual placeholder so users can see where the Eventin
		// single event template output will appear inside the Oxygen layout.
		if ( defined( 'SHOW_CT_BUILDER' ) && SHOW_CT_BUILDER ) {
			echo '<div class="etn-oxygen-single-event-placeholder" style="border:1px dashed #999;padding:8px 10px;margin-bottom:10px;font-size:11px;line-height:1.4;color:#555;background:rgba(0,0,0,0.02);">Eventin Oxygen: Single Event template output starts here.</div>';
		}

		if ( $use_block_template ) {
			self::render_block_single_body( $post->ID );
		} else {
			self::render_default_single_body();
		}

		echo '</div>';
	}

	/**
	 * Return Eventin single event body as string (for the_content filter).
	 */
	public static function get_html() {
		ob_start();
		self::render();
		return ob_get_clean();
	}

	/**
	 * Body content from block-single-template.php (no header/footer).
	 */
	public static function render_block_single_body( $event_id ) {
		$default_template_name = array(
			'event-one'   => 'event-template-one',
			'event-two'   => 'event-template-two',
			'event-three' => 'event-template-three',
		);

		if ( post_password_required( $event_id ) ) {
			echo get_the_password_form( $event_id );
			return;
		}

		$event        = new \Etn\Core\Event\Event_Model( $event_id );
		$template_id  = $event->event_layout;
		if ( ! $template_id ) {
			$template_id = etn_get_option( 'event_template', 'event-one' );
		}

		$template = new \Eventin\Template\TemplateModel( $template_id );
		if ( $template && get_post_type( $template_id ) === 'etn-template' ) {
			$template->render_content( '', $event_id );
		} else {
			$template->render_content( isset( $default_template_name[ $template_id ] ) ? $default_template_name[ $template_id ] : 'event-template-one', $event_id );
		}
	}

	/**
	 * Body content equivalent to event-single-page.php, but without header/footer.
	 * Respects theme overrides for single-event.php, then falls back to plugin template.
	 */
	public static function render_default_single_body() {
		$etn_show_event = true;
		if ( isset( $_POST['ticket_purchase_next_step'] ) && ( $_POST['ticket_purchase_next_step'] !== 'two' || $_POST['ticket_purchase_next_step'] !== 'three' ) ) {
			$etn_show_event = false;
		}

		if ( ! $etn_show_event ) {
			return;
		}

		// Match Eventin's event-single-page.php logic for locating single-event.php,
		// but omit get_header()/get_footer() so Oxygen can handle layout.
		$child_theme_file  = get_stylesheet_directory() . \Wpeventin::theme_templates_dir() . 'single-event.php';
		$parent_theme_file = get_template_directory() . \Wpeventin::theme_templates_dir() . 'single-event.php';
		$plugin_file       = \Wpeventin::templates_dir() . 'single-event.php';

		if ( file_exists( $child_theme_file ) ) {
			require $child_theme_file;
		} elseif ( file_exists( $parent_theme_file ) ) {
			require $parent_theme_file;
		} elseif ( file_exists( $plugin_file ) ) {
			require $plugin_file;
		}
	}
}
