<?php

/**
 *  @package eventin-oxygen-addon
 */

/**
 * Plugin Name:        Eventin Oxygen Addon
 * Requires Plugins:   wp-event-solution
 * Plugin URI:         https://product.themewinter.com/eventin
 * Description:        Oxygen Builder Integration - Simple and Easy to use Event Management Solution. You can design pages by Oxygen Builder and Eventin.
 * Version:            1.0.2
 * Author:             Themewinter
 * Author URI:         http://themewinter.com/
 * License:            GPL-2.0+
 * License URI:        http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:        eventin-oxygen-addon
 * Domain Path:       /languages
 */

defined('ABSPATH') || exit;

final class Eventin_Oxygen_Addon
{

    /**
     * Plugin Version
     *
     * @since 1.0.0
     *
     * @var string The plugin version.
     */
    public static function version()
    {
        return '1.0.2';
    }

    /**
     * Instance of self
     *
     * @since 1.0.0
     *
     * @var Eventin_Oxygen_Addon
     */
    private static $instance = null;

    /**
     * Initializes the Eventin_Oxygen_Addon() class
     *
     * Checks for an existing Eventin_Oxygen_Addon() instance
     * and if it doesn't find one, creates it.
     */
    public static function init()
    {

        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Instance of Eventin_Oxygen_Addon
     */
    private function __construct()
    {
        // Load translations on init (WP 6.7+ requirement).
        add_action( 'init', [ $this, 'load_textdomain' ], 5 );

        // Instantiate Base Class after plugins loaded
        add_action('plugins_loaded', [$this, 'initialize_modules'], 999);
    }

    /**
     * Load plugin translations.
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'eventin-oxygen-addon',
            false,
            dirname( plugin_basename( self::plugin_file() ) ) . '/languages'
        );
    }

    /**
     * Initialize Modules
     *
     * @since 1.0.0
     */
    public function initialize_modules()
    {

        do_action('etnoa/before_load');

        require_once self::plugin_dir() . 'bootstrap.php';

        // action plugin instance class
        $plugin_bootstrap = new \Eventin_Oxygen_Addon\Bootstrap();
        $plugin_bootstrap->init();

        do_action('etnoa/after_load');
    }

    /**
     * Assets Directory Url
     *
     * @return void
     */
    public static function assets_url()
    {
        return trailingslashit(self::plugin_url() . 'assets');
    }

    /**
     * Assets Folder Directory Path
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function assets_dir()
    {
        return trailingslashit(self::plugin_dir() . 'assets');
    }

    /**
     * Plugin Core File Directory Url
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function core_url()
    {
        return trailingslashit(self::plugin_url() . 'core');
    }

    /**
     * Plugin Core File Directory Path
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function core_dir()
    {
        return trailingslashit(self::plugin_dir() . 'core');
    }

    /**
     * Plugin Url
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function plugin_url()
    {
        return trailingslashit(plugin_dir_url(self::plugin_file()));
    }

    /**
     * Plugin Directory Path
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function plugin_dir()
    {
        return trailingslashit(plugin_dir_path(self::plugin_file()));
    }

    /**
     * Plugins Basename
     *
     * @since 1.0.0

     */
    public static function plugins_basename()
    {
        return plugin_basename(self::plugin_file());
    }

    /**
     * Plugin File
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function plugin_file()
    {
        return __FILE__;
    }
}

/**
 * Load Eventin Oxygen Addon when all plugins are loaded
 *
 * @return Eventin_Oxygen_Addon
 */
function eventin_oxygen_addon()
{
    return Eventin_Oxygen_Addon::init();
}

// Let's Go...
add_action( 'plugins_loaded', 'eventin_oxygen_addon', 0 );